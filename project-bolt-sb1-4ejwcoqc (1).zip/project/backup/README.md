# Recipe Generator Backup

This is a backup of the Recipe Generator project. The backup includes all source files and configurations.

## Project Structure

```
src/
  ├── components/     # React components
  ├── config/        # Configuration files
  ├── lib/           # Core libraries
  ├── services/      # Business logic and API services
  ├── types/         # TypeScript type definitions
  └── utils/         # Utility functions
```

## Environment Variables

Required environment variables:
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY
- VITE_OPENAI_API_KEY
- VITE_RECRAFT_API_KEY