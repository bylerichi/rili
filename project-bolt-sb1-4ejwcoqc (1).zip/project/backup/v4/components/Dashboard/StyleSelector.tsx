import React, { useState, useEffect } from 'react';
import { styleService } from '../../services/recraft/style-service';
import type { CustomStyle } from '../../services/recraft/types';

interface StyleSelectorProps {
  value: string;
  onChange: (styleId: string) => void;
  disabled?: boolean;
}

export function StyleSelector({ value, onChange, disabled }: StyleSelectorProps) {
  const [styles, setStyles] = useState<CustomStyle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadStyles();
  }, []);

  const loadStyles = async () => {
    try {
      const userStyles = await styleService.list();
      setStyles(userStyles);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to load styles');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse h-10 bg-gray-100 rounded"></div>
    );
  }

  if (error) {
    return (
      <div className="text-sm text-red-600">{error}</div>
    );
  }

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">
        Style
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
      >
        <option value="realistic_image">Default Style</option>
        {styles.map((style) => (
          <option key={style.id} value={style.id}>
            {style.name}
          </option>
        ))}
      </select>
    </div>
  );
}