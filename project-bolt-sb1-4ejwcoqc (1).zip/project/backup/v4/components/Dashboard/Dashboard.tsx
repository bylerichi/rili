import React from 'react';
import { BatchRecipeGenerator } from './BatchRecipeGenerator';
import { Header } from './Header';

export function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <BatchRecipeGenerator />
      </main>
    </div>
  );
}