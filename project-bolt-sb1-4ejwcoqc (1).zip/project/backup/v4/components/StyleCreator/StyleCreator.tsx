import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ImageUpload } from './ImageUpload';
import { useAuth } from '../../hooks/useAuth';
import { useStyleCreation } from './hooks/useStyleCreation';
import { useFileUpload } from './hooks/useFileUpload';
import { SuccessMessage } from './SuccessMessage';
import { StyleTester } from './StyleTester';

export function StyleCreator() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { loading, error: styleError, success, createStyle } = useStyleCreation(user?.id || '');
  const { files, error: fileError, addFiles, removeFile } = useFileUpload();
  const [styleName, setStyleName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || files.length === 0 || !user || !styleName.trim()) return;

    try {
      await createStyle('realistic_image', files, styleName);
    } catch (error) {
      // Error is handled by useStyleCreation
    }
  };

  if (success) {
    return (
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <Link
            to="/"
            className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
          >
            <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Dashboard
          </Link>
          <button
            onClick={() => navigate('/styles')}
            className="text-sm text-indigo-600 hover:text-indigo-900"
          >
            View All Styles
          </button>
        </div>
        <SuccessMessage styleId={success.styleId} styleName={success.styleName} />
        <StyleTester styleId={success.styleId} styleName={success.styleName} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Link
          to="/"
          className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
        >
          <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to Dashboard
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-6">Create Custom Style</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="styleName" className="block text-sm font-medium text-gray-700 mb-1">
              Style Name
            </label>
            <input
              type="text"
              id="styleName"
              value={styleName}
              onChange={(e) => setStyleName(e.target.value)}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="Enter a name for your style"
              disabled={loading}
              required
            />
          </div>

          <ImageUpload
            files={files}
            onFilesChange={addFiles}
            onRemoveFile={removeFile}
            disabled={loading}
            error={fileError}
          />

          {styleError && (
            <div className="rounded-md bg-red-50 p-4">
              <p className="text-sm text-red-700">{styleError}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || files.length === 0 || !styleName.trim()}
            className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
          >
            {loading ? 'Creating Style...' : 'Create Style'}
          </button>
        </form>
      </div>
    </div>
  );
}