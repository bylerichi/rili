import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { Dashboard } from './components/Dashboard/Dashboard';
import { LoginForm } from './components/auth/LoginForm';
import { StyleCreator } from './components/StyleCreator/StyleCreator';
import { CustomStylesPage } from './pages/CustomStylesPage';
import { PrivateRoute } from './components/auth/PrivateRoute';

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginForm />} />
          <Route element={<PrivateRoute />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/styles" element={<CustomStylesPage />} />
            <Route path="/styles/new" element={<StyleCreator />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}