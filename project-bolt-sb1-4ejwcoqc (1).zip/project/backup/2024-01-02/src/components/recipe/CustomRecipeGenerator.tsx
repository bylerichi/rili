import React, { useState } from 'react';
import { generateRecipe } from '../../services/openai';
import { generateImage } from '../../services/recraft/client';
import { parseRecipeText } from '../../services/recipe/parser';

interface RecipeResult {
  recipe?: {
    title: string;
    description: string;
    ingredients: string;
    instructions: string;
    hashtags: string;
  };
  imageUrl?: string;
  error?: string;
}

export function CustomRecipeGenerator() {
  const [recipeName, setRecipeName] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RecipeResult | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipeName.trim() || loading) return;

    setLoading(true);
    setResult(null);

    try {
      // 1. Générer le texte de la recette
      const recipeText = await generateRecipe(recipeName);
      const parsed = parseRecipeText(recipeText);
      
      // 2. Générer l'image avec le prompt de vue du dessus
      const imageUrl = await generateImage(parsed.imagePrompt, {
        style: 'realistic_image'
      });
      
      setResult({
        recipe: {
          title: parsed.title,
          description: parsed.description,
          ingredients: parsed.ingredients,
          instructions: parsed.instructions,
          hashtags: parsed.hashtags
        },
        imageUrl
      });
    } catch (error) {
      setResult({
        error: error instanceof Error ? error.message : 'Erreur inconnue'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadText = () => {
    if (!result?.recipe) return;
    
    const content = `${result.recipe.title}\n\n` +
      `Description:\n${result.recipe.description}\n\n` +
      `Ingrédients:\n${result.recipe.ingredients}\n\n` +
      `Instructions:\n${result.recipe.instructions}\n\n` +
      `Tags: ${result.recipe.hashtags}`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${recipeName.toLowerCase().replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadImage = async () => {
    if (!result?.imageUrl) return;
    
    try {
      const response = await fetch(result.imageUrl);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${recipeName.toLowerCase().replace(/\s+/g, '-')}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Erreur lors du téléchargement de l\'image:', error);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-4">Générer une recette personnalisée</h2>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="mb-4">
          <label htmlFor="recipeName" className="block text-sm font-medium text-gray-700">
            Nom de la recette
          </label>
          <input
            type="text"
            id="recipeName"
            value={recipeName}
            onChange={(e) => setRecipeName(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Ex: Gâteau au chocolat"
            disabled={loading}
          />
        </div>

        <button
          type="submit"
          disabled={loading || !recipeName.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Génération en cours...' : 'Générer'}
        </button>
      </form>

      {result && (
        <div className="mt-4">
          {result.error ? (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{result.error}</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Contenu de la recette */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold">{result.recipe?.title}</h3>
                
                <div>
                  <h4 className="font-semibold mb-2">Description:</h4>
                  <p className="text-gray-700">{result.recipe?.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Ingrédients:</h4>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe?.ingredients}</pre>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Instructions:</h4>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe?.instructions}</pre>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Tags:</h4>
                  <p className="text-gray-700">{result.recipe?.hashtags}</p>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={handleDownloadText}
                    className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
                  >
                    Télécharger la recette
                  </button>
                  <button
                    onClick={handleDownloadImage}
                    className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                  >
                    Télécharger l'image
                  </button>
                </div>
              </div>

              {/* Image générée */}
              <div>
                <h4 className="font-semibold mb-2">Image générée:</h4>
                <img 
                  src={result.imageUrl} 
                  alt="Recette générée" 
                  className="max-w-full h-auto rounded-lg shadow-md"
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}