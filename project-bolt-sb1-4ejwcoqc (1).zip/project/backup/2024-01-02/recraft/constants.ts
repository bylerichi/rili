export const RECRAFT_API = {
  BASE_URL: 'https://external.api.recraft.ai',
  VERSION: 'v1',
  ENDPOINTS: {
    GENERATE: '/images/generations'
  }
} as const;

export const DEFAULT_CONFIG = {
  resolution: '1024x1024',
  style: 'realistic_image',
  num_images: 1
} as const;

export type RecraftStyle = 
  | 'realistic_image'
  | 'digital_illustration'
  | 'anime'
  | 'painting'
  | 'sketch'
  | 'comic_book'
  | 'pixel_art'
  | 'abstract';