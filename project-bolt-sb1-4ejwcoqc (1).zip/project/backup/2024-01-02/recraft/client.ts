import axios from 'axios';
import { RECRAFT_API, DEFAULT_CONFIG } from './constants';
import type { GenerateImageParams, RecraftResponse } from './types';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;

export async function generateImage(
  prompt: string,
  options: Partial<Omit<GenerateImageParams, 'prompt'>> = {}
): Promise<string> {
  const url = `${RECRAFT_API.BASE_URL}/${RECRAFT_API.VERSION}${RECRAFT_API.ENDPOINTS.GENERATE}`;
  
  try {
    const response = await axios.post<RecraftResponse>(
      url,
      {
        prompt,
        resolution: options.resolution || DEFAULT_CONFIG.resolution,
        style: options.style || DEFAULT_CONFIG.style,
        num_images: options.num_images || DEFAULT_CONFIG.num_images
      },
      {
        headers: {
          'Authorization': `Bearer ${RECRAFT_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const imageUrl = response.data?.data?.[0]?.url;
    if (!imageUrl) {
      throw new Error('No image URL in response');
    }

    return imageUrl;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(`Recraft API error: ${error.response?.data?.message || error.message}`);
    }
    throw error;
  }
}