import type { RecraftStyle } from './constants';

export interface GenerateImageParams {
  prompt: string;
  style?: RecraftStyle;
  resolution?: string;
  num_images?: number;
}

export interface RecraftResponse {
  data: Array<{
    url: string;
  }>;
}

export interface RecraftError {
  message: string;
  status?: number;
}