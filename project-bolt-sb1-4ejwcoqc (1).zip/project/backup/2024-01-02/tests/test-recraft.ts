import { generateImage } from '../services/recraft/client';

async function testRecraft() {
  try {
    console.log('Testing Recraft API...');
    const prompt = 'red car on a track';
    
    console.log('Generating image for prompt:', prompt);
    const imageUrl = await generateImage(prompt, {
      style: 'realistic_image'
    });
    
    console.log('Image generated successfully!');
    console.log('Image URL:', imageUrl);
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

testRecraft();