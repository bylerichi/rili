import React, { useState } from 'react';
import { generateRecipe } from '../../services/openai';
import { generateImage } from '../../services/recraft/client';
import { parseRecipeText } from '../../services/recipe/parser';

interface RecipeResult {
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  recipe?: {
    title: string;
    description: string;
    ingredients: string;
    instructions: string;
    hashtags: string;
  };
  imageUrl?: string;
  error?: string;
}

export function BatchRecipeGenerator() {
  const [recipeNames, setRecipeNames] = useState('');
  const [results, setResults] = useState<RecipeResult[]>([]);
  const [processing, setProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipeNames.trim() || processing) return;

    const names = recipeNames
      .split('\n')
      .map(name => name.trim())
      .filter(name => name)
      .slice(0, 25);

    if (names.length === 0) return;

    setProcessing(true);
    setResults(names.map(name => ({ name, status: 'pending' })));

    for (let i = 0; i < names.length; i++) {
      const name = names[i];
      
      setResults(prev => prev.map(result => 
        result.name === name 
          ? { ...result, status: 'processing' }
          : result
      ));

      try {
        // 1. Générer la recette
        const recipeText = await generateRecipe(name);
        const parsed = parseRecipeText(recipeText);
        
        // 2. Générer l'image
        const imageUrl = await generateImage(parsed.imagePrompt, {
          style: 'realistic_image'
        });
        
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'completed',
                recipe: {
                  title: parsed.title,
                  description: parsed.description,
                  ingredients: parsed.ingredients,
                  instructions: parsed.instructions,
                  hashtags: parsed.hashtags
                },
                imageUrl
              }
            : result
        ));
      } catch (error) {
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'error',
                error: error instanceof Error ? error.message : 'Erreur inconnue'
              }
            : result
        ));
      }
    }

    setProcessing(false);
  };

  const handleDownloadText = (result: RecipeResult) => {
    if (!result.recipe) return;
    
    const content = `${result.recipe.title}\n\n` +
      `Description:\n${result.recipe.description}\n\n` +
      `Ingrédients:\n${result.recipe.ingredients}\n\n` +
      `Instructions:\n${result.recipe.instructions}\n\n` +
      `Tags: ${result.recipe.hashtags}`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${result.name.toLowerCase().replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadImage = async (result: RecipeResult) => {
    if (!result.imageUrl) return;
    
    try {
      const response = await fetch(result.imageUrl);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${result.name.toLowerCase().replace(/\s+/g, '-')}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Erreur lors du téléchargement de l\'image:', error);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-4">Générer plusieurs recettes</h2>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="mb-4">
          <label htmlFor="recipeNames" className="block text-sm font-medium text-gray-700">
            Noms des recettes (une par ligne, maximum 25)
          </label>
          <textarea
            id="recipeNames"
            value={recipeNames}
            onChange={(e) => setRecipeNames(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Gâteau au chocolat&#10;Tarte aux pommes&#10;Poulet rôti"
            rows={10}
            disabled={processing}
          />
        </div>

        <button
          type="submit"
          disabled={processing || !recipeNames.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {processing ? 'Génération en cours...' : 'Générer les recettes'}
        </button>
      </form>

      {results.length > 0 && (
        <div className="space-y-6">
          <h3 className="text-lg font-semibold">Résultats</h3>
          
          <div className="grid gap-6">
            {results.map((result) => (
              <div 
                key={result.name}
                className={`p-4 rounded-lg border ${
                  result.status === 'completed' ? 'border-green-200 bg-green-50' :
                  result.status === 'error' ? 'border-red-200 bg-red-50' :
                  result.status === 'processing' ? 'border-blue-200 bg-blue-50' :
                  'border-gray-200 bg-gray-50'
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">{result.name}</h4>
                  <span className={`px-2 py-1 rounded text-sm ${
                    result.status === 'completed' ? 'bg-green-100 text-green-800' :
                    result.status === 'error' ? 'bg-red-100 text-red-800' :
                    result.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {result.status === 'completed' ? 'Terminé' :
                     result.status === 'error' ? 'Erreur' :
                     result.status === 'processing' ? 'En cours' :
                     'En attente'}
                  </span>
                </div>

                {result.error ? (
                  <p className="text-red-600">{result.error}</p>
                ) : result.status === 'completed' && result.recipe && result.imageUrl ? (
                  <div className="space-y-4">
                    <div className="flex gap-4">
                      <button
                        onClick={() => handleDownloadText(result)}
                        className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
                      >
                        Télécharger la recette
                      </button>
                      <button
                        onClick={() => handleDownloadImage(result)}
                        className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                      >
                        Télécharger l'image
                      </button>
                    </div>
                    
                    <img 
                      src={result.imageUrl} 
                      alt={result.name}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}