import React from 'react';
import { MainLayout } from './components/layout/MainLayout';
import { Dashboard } from './components/recipe/Dashboard';

function App() {
  return (
    <MainLayout>
      <Dashboard />
    </MainLayout>
  );
}

export default App;