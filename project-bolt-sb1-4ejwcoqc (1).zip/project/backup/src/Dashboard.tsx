import React from 'react';
import { RecipeInput } from './RecipeInput';
import { RecipeList } from './RecipeList';
import { TestRecraft } from './TestRecraft';
import { TestPrompt } from './TestPrompt';

export function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Tableau de bord</h1>
      <RecipeInput />
      <TestRecraft />
      <TestPrompt />
      <RecipeList />
    </div>
  );
}