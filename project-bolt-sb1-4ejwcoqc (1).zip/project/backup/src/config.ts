export const RECRAFT_CONFIG = {
  API_URL: 'https://external.api.recraft.ai/v1',
  ENDPOINTS: {
    GENERATE: '/images/generations'
  },
  DEFAULTS: {
    MODEL: 'recraftv3' as const,
    STYLE: 'realistic_image' as const,
    SIZE: '1024x1024' as const,
    RESPONSE_FORMAT: 'url' as const,
    SUBSTYLE: 'natural_light' as const
  }
} as const;