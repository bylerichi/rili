import axios from 'axios';
import { API_CONFIG } from '../../config/api';
import { delay } from '../../utils/delay';
import { logError } from '../../utils/error';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;
const MAX_RETRIES = 3;
const RETRY_DELAY = 2000;

interface GenerateImageOptions {
  width?: number;
  height?: number;
  num_images?: number;
  guidance_scale?: number;
}

export async function generateImage(
  prompt: string,
  options: GenerateImageOptions = {}
): Promise<string> {
  const config = API_CONFIG.recraft;
  const url = `${config.baseUrl}/${config.version}${config.endpoints.generate}`;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      if (attempt > 1) {
        await delay(RETRY_DELAY);
      }

      const response = await axios.post(
        url,
        {
          prompt,
          width: options.width || config.defaults.width,
          height: options.height || config.defaults.height,
          num_images: config.defaults.numImages,
          guidance_scale: options.guidance_scale || config.defaults.guidanceScale
        },
        {
          headers: {
            'Authorization': `Bearer ${RECRAFT_API_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!response.data?.imageUrl) {
        throw new Error('Pas d\'URL d\'image dans la réponse');
      }

      return response.data.imageUrl;
    } catch (error: any) {
      logError('generateImage', `Tentative ${attempt} échouée: ${error.message}`);
      
      if (error.response?.status === 401) {
        throw new Error('Clé API Recraft invalide ou expirée. Veuillez vérifier votre configuration.');
      }
      
      if (attempt === MAX_RETRIES) {
        throw new Error(`Échec après ${MAX_RETRIES} tentatives: ${error.message}`);
      }
    }
  }

  throw new Error('Erreur inattendue lors de la génération d\'image');
}