import { generateRecipe } from '../openai';
import { generateImage } from '../recraft/client';
import { parseRecipeText } from './parser';
import { GeneratedFiles } from './types';

export async function processRecipe(recipeName: string): Promise<GeneratedFiles> {
  try {
    // Générer le texte avec ChatGPT
    const recipeText = await generateRecipe(recipeName);
    const parts = parseRecipeText(recipeText);
    
    // Créer le fichier texte
    const recipeContent = `${parts.title}\n\n${parts.description}\n\n${parts.ingredients}\n\n${parts.instructions}`;
    
    // Générer l'image avec Recraft
    const imageUrl = await generateImage(parts.imagePrompt);
    
    return {
      recipeText: recipeContent,
      imageUrl
    };
  } catch (error) {
    throw new Error(`Erreur de génération: ${error.message}`);
  }
}