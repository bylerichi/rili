import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import { storage } from '../lib/storage';
import { auth } from '../lib/auth';
import { generateRecipe } from '../services/openai';
import { generateImage } from '../services/recraft';

export function FileUpload() {
  const processCSV = async (file: File) => {
    const text = await file.text();
    Papa.parse(text, {
      complete: async (results) => {
        const { data } = results;
        const user = auth.getUser();
        if (!user) return;

        for (const row of data) {
          try {
            // Générer la recette avec ChatGPT
            const recipeText = await generateRecipe(row.toString());
            const parts = recipeText.split('\n\n');
            
            const recipeName = parts[0];
            const topViewPrompt = parts[1];
            const closeUpPrompt = parts[2];
            const ingredients = parts[3];
            const instructions = parts[4];

            // Générer les images
            const topViewImage = await generateImage(topViewPrompt);
            const closeUpImage = await generateImage(closeUpPrompt);

            // Sauvegarder le fichier texte
            const recipeContent = `${ingredients}\n\n${instructions}`;
            await storage.saveRecipe(user.id, recipeName, recipeContent);

            // Sauvegarder les images
            const topViewResponse = await fetch(topViewImage);
            const closeUpResponse = await fetch(closeUpImage);
            
            const topViewBuffer = await topViewResponse.arrayBuffer();
            const closeUpBuffer = await closeUpResponse.arrayBuffer();

            await storage.saveImage(user.id, recipeName, Buffer.from(topViewBuffer), 'top-view.jpg');
            await storage.saveImage(user.id, recipeName, Buffer.from(closeUpBuffer), 'close-up.jpg');

          } catch (error) {
            console.error('Erreur lors du traitement de la ligne:', error);
          }
        }
      }
    });
  };

  const onDrop = useCallback((acceptedFiles) => {
    acceptedFiles.forEach(processCSV);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'text/csv': ['.csv']
    }
  });

  return (
    <div className="p-6">
      <div
        {...getRootProps()}
        className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center cursor-pointer hover:border-indigo-500"
      >
        <input {...getInputProps()} />
        {isDragActive ? (
          <p>Déposez le fichier ici...</p>
        ) : (
          <p>Glissez et déposez un fichier CSV ici, ou cliquez pour sélectionner</p>
        )}
      </div>
    </div>
  );
}