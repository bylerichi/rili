/*
  # Storage setup for recipes

  1. New Buckets
    - Creates 'recipes' storage bucket for user files
  
  2. Security
    - Enables RLS policies for file access
    - Users can only access their own files
    - Files are organized by user ID
*/

BEGIN;

-- Create recipes bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('recipes', 'recipes', false)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can upload their own files" ON storage.objects;
DROP POLICY IF EXISTS "Users can read their own files" ON storage.objects;

-- Create upload policy
CREATE POLICY "Users can upload their own files"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'recipes' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Create read policy
CREATE POLICY "Users can read their own files"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'recipes' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

COMMIT;