-- Create function to safely add tokens
CREATE OR REPLACE FUNCTION add_tokens(
  p_user_id UUID,
  p_amount INTEGER,
  p_description TEXT
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert transaction first
  INSERT INTO token_transactions (
    user_id,
    amount,
    type,
    description
  ) VALUES (
    p_user_id,
    p_amount,
    'purchase',
    p_description
  );

  -- Then update balance
  INSERT INTO user_tokens (
    user_id,
    balance,
    updated_at
  ) VALUES (
    p_user_id,
    p_amount,
    now()
  )
  ON CONFLICT (user_id) DO UPDATE
  SET 
    balance = user_tokens.balance + p_amount,
    updated_at = now();
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION add_tokens TO authenticated;