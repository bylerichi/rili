/*
  # Token Management System

  1. New Tables
    - `user_tokens`
      - `user_id` (uuid, primary key, references auth.users)
      - `balance` (integer, default 0)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `token_transactions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `amount` (integer)
      - `type` (text, either 'purchase' or 'spend')
      - `description` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for user access
*/

-- Create user_tokens table
CREATE TABLE IF NOT EXISTS user_tokens (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id),
  balance INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create token_transactions table
CREATE TABLE IF NOT EXISTS token_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  amount INTEGER NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('purchase', 'spend')),
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE token_transactions ENABLE ROW LEVEL SECURITY;

-- Policies for user_tokens
CREATE POLICY "Users can view their own token balance"
  ON user_tokens
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies for token_transactions
CREATE POLICY "Users can view their own transactions"
  ON token_transactions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own transactions"
  ON token_transactions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Function to update token balance
CREATE OR REPLACE FUNCTION update_token_balance()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert or update user_tokens
  INSERT INTO user_tokens (user_id, balance)
  VALUES (NEW.user_id, CASE WHEN NEW.type = 'purchase' THEN NEW.amount ELSE -NEW.amount END)
  ON CONFLICT (user_id) DO UPDATE
  SET balance = user_tokens.balance + (CASE WHEN NEW.type = 'purchase' THEN NEW.amount ELSE -NEW.amount END),
      updated_at = now();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for updating token balance
CREATE TRIGGER update_token_balance_trigger
  AFTER INSERT ON token_transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_token_balance();