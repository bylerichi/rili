/*
  # Token System Setup

  1. New Tables
    - `user_tokens`: Stores user token balances
    - `token_transactions`: Records token purchases and usage

  2. Security
    - Enable RLS on both tables
    - Add policies for user access
    - Add trigger for automatic balance updates

  3. Changes
    - Add function to update token balance
    - Add trigger for transaction processing
*/

-- Create user_tokens table if not exists
CREATE TABLE IF NOT EXISTS user_tokens (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id),
  balance INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create token_transactions table if not exists
CREATE TABLE IF NOT EXISTS token_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  amount INTEGER NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('purchase', 'spend')),
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE token_transactions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view their own token balance" ON user_tokens;
DROP POLICY IF EXISTS "Users can insert their own token balance" ON user_tokens;
DROP POLICY IF EXISTS "Users can update their own token balance" ON user_tokens;
DROP POLICY IF EXISTS "Users can view their own transactions" ON token_transactions;
DROP POLICY IF EXISTS "Users can insert their own transactions" ON token_transactions;

-- Create new policies
CREATE POLICY "Users can view their own token balance"
  ON user_tokens
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own token balance"
  ON user_tokens
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own token balance"
  ON user_tokens
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own transactions"
  ON token_transactions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own transactions"
  ON token_transactions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Drop existing function and trigger if they exist
DROP TRIGGER IF EXISTS update_token_balance_trigger ON token_transactions;
DROP FUNCTION IF EXISTS update_token_balance();

-- Create function to update token balance
CREATE OR REPLACE FUNCTION update_token_balance()
RETURNS TRIGGER AS $$
DECLARE
  current_balance INTEGER;
  new_balance INTEGER;
BEGIN
  -- Get current balance
  SELECT balance INTO current_balance
  FROM user_tokens
  WHERE user_id = NEW.user_id;

  -- Calculate new balance
  IF NEW.type = 'purchase' THEN
    new_balance := COALESCE(current_balance, 0) + NEW.amount;
  ELSE
    -- Check if user has enough tokens for spending
    IF COALESCE(current_balance, 0) < NEW.amount THEN
      RETURN NULL; -- Abort the transaction
    END IF;
    new_balance := COALESCE(current_balance, 0) - NEW.amount;
  END IF;

  -- Insert or update user_tokens
  INSERT INTO user_tokens (user_id, balance)
  VALUES (NEW.user_id, new_balance)
  ON CONFLICT (user_id) DO UPDATE
  SET 
    balance = EXCLUDED.balance,
    updated_at = now();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for updating token balance
CREATE TRIGGER update_token_balance_trigger
  AFTER INSERT ON token_transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_token_balance();