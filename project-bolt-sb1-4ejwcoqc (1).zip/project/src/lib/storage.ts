import { supabase } from './supabase';

class Storage {
  async listRecipes(userId: string): Promise<string[]> {
    const { data, error } = await supabase.storage
      .from('recipes')
      .list(`${userId}/`);
    if (error) throw error;
    return data.map(item => item.name);
  }

  async listFiles(userId: string, recipeName: string): Promise<string[]> {
    const { data, error } = await supabase.storage
      .from('recipes')
      .list(`${userId}/${recipeName}/`);
    if (error) throw error;
    return data.map(item => item.name);
  }
}

export const storage = new Storage();