export function normalizeText(text: string): string {
  return text
    .replace(/\r\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export function extractBetweenMarkers(
  text: string,
  startMarker: string,
  endMarker?: string
): string {
  const start = text.indexOf(startMarker);
  if (start === -1) return '';

  const contentStart = start + startMarker.length;
  
  if (!endMarker) {
    return text.slice(contentStart).trim();
  }

  const end = text.indexOf(endMarker, contentStart);
  if (end === -1) return text.slice(contentStart).trim();
  
  return text.slice(contentStart, end).trim();
}