import Papa from 'papaparse';
import { RecipeRow } from '../types/recipe';

export async function parseCSV(file: File): Promise<RecipeRow[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      complete: (results) => {
        resolve(results.data as RecipeRow[]);
      },
      error: (error) => {
        reject(error);
      }
    });
  });
}