// Error utilities for consistent error handling
export function formatError(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  if (typeof error === 'string') {
    return error;
  }
  return 'Une erreur inconnue est survenue';
}

export function logError(context: string, error: unknown): void {
  console.error(`[${context}]`, {
    message: formatError(error),
    error,
    timestamp: new Date().toISOString(),
  });
}