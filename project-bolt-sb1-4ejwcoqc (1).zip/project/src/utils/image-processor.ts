import { MAX_STYLE_IMAGES } from '../services/recraft/constants';

export interface ProcessedImage {
  file: File;
  originalName: string;
}

export async function processImage(file: File): Promise<ProcessedImage> {
  // Check if already PNG with correct size
  if (file.type === 'image/png') {
    return { file, originalName: file.name };
  }

  // Create canvas and load image
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;
  const img = new Image();

  // Convert to promise-based operation
  const loadImage = new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = URL.createObjectURL(file);
  });

  await loadImage;

  // Set canvas size to 1024x1024 (Recraft requirement)
  canvas.width = 1024;
  canvas.height = 1024;

  // Draw image maintaining aspect ratio
  const scale = Math.min(canvas.width / img.width, canvas.height / img.height);
  const x = (canvas.width - img.width * scale) / 2;
  const y = (canvas.height - img.height * scale) / 2;
  
  // Fill background with white
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Draw image centered
  ctx.drawImage(img, x, y, img.width * scale, img.height * scale);

  // Convert to PNG blob
  const blob = await new Promise<Blob>((resolve) => {
    canvas.toBlob(blob => resolve(blob!), 'image/png', 1.0);
  });

  // Create file name
  const fileName = file.name.replace(/\.[^/.]+$/, '') + '.png';
  
  // Create new File object
  const processedFile = new File([blob], fileName, { type: 'image/png' });

  // Cleanup
  URL.revokeObjectURL(img.src);

  return {
    file: processedFile,
    originalName: file.name
  };
}

export async function processImages(files: File[]): Promise<ProcessedImage[]> {
  if (files.length > MAX_STYLE_IMAGES) {
    throw new Error(`Maximum ${MAX_STYLE_IMAGES} images allowed`);
  }

  const processedImages = await Promise.all(
    files.map(file => processImage(file))
  );

  return processedImages;
}