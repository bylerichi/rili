import type { RecipeResult } from '../components/Dashboard/types';

export function downloadText(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadImage(url: string, filename: string): Promise<void> {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(objectUrl);
  } catch (error) {
    console.error('Error downloading image:', error);
    throw new Error('Failed to download image');
  }
}

export function formatRecipeContent(recipe: RecipeResult['recipe']): string {
  if (!recipe) return '';
  
  return `${recipe.title}\n\n` +
    `Description:\n${recipe.description}\n\n` +
    `Ingredients:\n${recipe.ingredients}\n\n` +
    `Instructions:\n${recipe.instructions}\n\n` +
    `Tags: ${recipe.hashtags}`;
}

export async function downloadRecipeWithImage(result: RecipeResult): Promise<void> {
  if (!result.recipe || !result.imageUrl) return;

  try {
    // Download recipe text
    const content = formatRecipeContent(result.recipe);
    const textFilename = `${result.name.toLowerCase().replace(/\s+/g, '-')}.txt`;
    downloadText(content, textFilename);

    // Download image
    const imageFilename = `${result.name.toLowerCase().replace(/\s+/g, '-')}.jpg`;
    await downloadImage(result.imageUrl, imageFilename);
  } catch (error) {
    console.error('Error downloading recipe:', error);
    throw new Error('Failed to download recipe');
  }
}

export async function downloadAllRecipes(results: RecipeResult[]): Promise<void> {
  const completedRecipes = results.filter(
    result => result.status === 'completed' && result.recipe && result.imageUrl
  );

  if (completedRecipes.length === 0) return;

  for (const recipe of completedRecipes) {
    try {
      await downloadRecipeWithImage(recipe);
    } catch (error) {
      console.error(`Failed to download recipe ${recipe.name}:`, error);
    }
  }
}