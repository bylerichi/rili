import { RecipeRow } from '../types/recipe';

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export function validateRecipeData(recipe: RecipeRow): void {
  if (!recipe || typeof recipe !== 'object') {
    throw new ValidationError('Format de recette invalide');
  }

  if (!recipe['Recipe Name']?.trim()) {
    throw new ValidationError('Le nom de la recette est requis');
  }
  
  if (!recipe['Status']?.trim()) {
    throw new ValidationError('Le statut est requis');
  }
  
  if (recipe['Status'].toLowerCase() !== 'pending') {
    throw new ValidationError('Seules les recettes avec le statut "Pending" sont traitées');
  }
}