import React, { createContext, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { styleService } from '../services/recraft/style-service';

interface StyleContextType {
  setSelectedStyle: (styleId: string) => void;
  getSelectedStyle: () => string | null;
}

const StyleContext = createContext<StyleContextType | undefined>(undefined);

export function StyleProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      styleService.setUserId(user.id);
    }
  }, [user]);

  const value = {
    setSelectedStyle: styleService.setSelectedStyle.bind(styleService),
    getSelectedStyle: styleService.getSelectedStyle.bind(styleService)
  };

  return (
    <StyleContext.Provider value={value}>
      {children}
    </StyleContext.Provider>
  );
}

export function useStyle() {
  const context = useContext(StyleContext);
  if (context === undefined) {
    throw new Error('useStyle must be used within a StyleProvider');
  }
  return context;
}