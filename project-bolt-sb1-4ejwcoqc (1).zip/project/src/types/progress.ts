export interface ProcessingStatus {
  step: 'recipe' | 'text' | 'images';
  progress: number;
  message: string;
}