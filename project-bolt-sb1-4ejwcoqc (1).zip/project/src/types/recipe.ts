export interface RecipeRow {
  'Recipe Name': string;
  'Status': string;
}

export interface Recipe {
  name: string;
  status: string;
}