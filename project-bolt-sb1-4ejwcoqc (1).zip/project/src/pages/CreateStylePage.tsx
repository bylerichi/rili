import React from 'react';
import { useNavigate } from 'react-router-dom';
import { StyleCreator } from '../components/StyleCreator';

export function CreateStylePage() {
  const navigate = useNavigate();

  const handleStyleCreated = (styleId: string) => {
    // Navigate to test page with the style ID
    navigate('/styles/test', { 
      state: { styleId }
    });
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Create New Style</h1>
        <p className="mt-2 text-gray-600">
          Upload reference images to create your custom style
        </p>
      </div>
      
      <StyleCreator onStyleCreated={handleStyleCreated} />
    </div>
  );
}