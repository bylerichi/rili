import React from 'react';
import { Link } from 'react-router-dom';
import { TokenPurchaseDemo } from '../components/tokens/TokenPurchaseDemo';
import { TokenBalance } from '../components/tokens/TokenBalance';

export function TokensPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <main className="max-w-4xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Link
            to="/"
            className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
          >
            <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Dashboard
          </Link>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold">Token Management</h1>
          <div className="mt-4">
            <TokenBalance />
          </div>
        </div>

        <TokenPurchaseDemo />
      </main>
    </div>
  );
}