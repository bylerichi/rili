import { useState } from 'react';
import { useAuth } from './useAuth';
import { paypalService } from '../services/payment/paypal/service';
import { tokenService } from '../services/tokens/token-service';
import type { TokenPackage } from '../services/payment/types';

export function usePayment() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handlePurchase = async (pkg: TokenPackage): Promise<string | null> => {
    if (!user || loading) return null;

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      return await paypalService.createOrder(pkg);
    } catch (error) {
      setError('Failed to initialize payment');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = async (orderId: string, tokenAmount: number) => {
    if (!user) return;
    
    setLoading(true);
    setError(null);

    try {
      await paypalService.capturePayment(orderId);
      await tokenService.purchaseTokens(user.id, tokenAmount);
      setSuccess(`Successfully purchased ${tokenAmount} tokens!`);
    } catch (error) {
      setError('Payment processing failed');
    } finally {
      setLoading(false);
    }
  };

  const clearStatus = () => {
    setError(null);
    setSuccess(null);
  };

  return {
    loading,
    error,
    success,
    handlePurchase,
    handlePaymentSuccess,
    clearStatus
  };
}