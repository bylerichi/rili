import { useState, useEffect } from 'react';
import { tokenService } from '../services/tokens/token-service';
import type { TokenBalance } from '../services/tokens/types';

export function useTokenBalance(userId: string | undefined) {
  const [balance, setBalance] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    async function loadBalance() {
      if (!userId) {
        setLoading(false);
        return;
      }

      try {
        const data = await tokenService.getBalance(userId);
        if (mounted) {
          setBalance(data.balance);
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err.message : 'Failed to load balance');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadBalance();

    return () => {
      mounted = false;
    };
  }, [userId]);

  return { balance, loading, error };
}