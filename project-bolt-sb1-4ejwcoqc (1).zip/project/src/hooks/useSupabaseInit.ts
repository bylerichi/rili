import { useEffect, useState } from 'react';
import { initSupabase } from '../lib/supabase-config';

export function useSupabaseInit() {
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    try {
      initSupabase();
      setInitialized(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to initialize Supabase');
    }
  }, []);

  return { initialized, error };
}