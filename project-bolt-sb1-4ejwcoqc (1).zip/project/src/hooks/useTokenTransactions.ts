import { useState, useEffect } from 'react';
import { tokenService } from '../services/tokens/token-service';
import type { TokenTransaction } from '../services/tokens/types';

export function useTokenTransactions(userId: string | undefined) {
  const [transactions, setTransactions] = useState<TokenTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    async function loadTransactions() {
      if (!userId) {
        setLoading(false);
        return;
      }

      try {
        const data = await tokenService.getTransactions(userId);
        if (mounted) {
          setTransactions(data);
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err.message : 'Failed to load transactions');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadTransactions();

    return () => {
      mounted = false;
    };
  }, [userId]);

  return { transactions, loading, error };
}