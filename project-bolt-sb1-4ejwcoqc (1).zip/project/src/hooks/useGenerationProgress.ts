import { useState } from 'react';
import type { Step } from '../components/ui/ProgressSteps';

export function useGenerationProgress() {
  const [steps] = useState<Step[]>([
    { id: 'recipe', label: 'Génération de la recette', status: 'pending' },
    { id: 'image', label: 'Génération de l\'image', status: 'pending' }
  ]);
  const [currentStep, setCurrentStep] = useState(0);

  const updateStepStatus = (stepId: string, status: Step['status']) => {
    steps.forEach(step => {
      if (step.id === stepId) {
        step.status = status;
      }
    });
  };

  const moveToNextStep = () => {
    setCurrentStep(prev => Math.min(prev + 1, steps.length - 1));
  };

  const resetProgress = () => {
    steps.forEach(step => {
      step.status = 'pending';
    });
    setCurrentStep(0);
  };

  return {
    steps,
    currentStep,
    updateStepStatus,
    moveToNextStep,
    resetProgress
  };
}