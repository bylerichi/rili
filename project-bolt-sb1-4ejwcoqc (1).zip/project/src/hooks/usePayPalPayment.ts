import { useState, useCallback } from 'react';
import { useAuth } from './useAuth';
import { paypalService } from '../services/payment/paypal/service';
import { tokenService } from '../services/tokens/token-service';
import type { TokenPackage } from '../services/payment/types';

export function usePayPalPayment() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handlePayment = useCallback(async (pkg: TokenPackage) => {
    if (!user || loading) return null;

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const orderId = await paypalService.createOrder(pkg);
      return orderId;
    } catch (error) {
      setError('Failed to initialize payment');
      return null;
    } finally {
      setLoading(false);
    }
  }, [user, loading]);

  const handlePaymentSuccess = useCallback(async (orderId: string, tokenAmount: number) => {
    if (!user) return;
    
    setLoading(true);
    setError(null);

    try {
      await paypalService.capturePayment(orderId);
      await tokenService.purchaseTokens(user.id, tokenAmount);
      setSuccess(`Successfully purchased ${tokenAmount} tokens!`);
    } catch (error) {
      setError('Payment processing failed');
    } finally {
      setLoading(false);
    }
  }, [user]);

  return {
    loading,
    error,
    success,
    handlePayment,
    handlePaymentSuccess
  };
}