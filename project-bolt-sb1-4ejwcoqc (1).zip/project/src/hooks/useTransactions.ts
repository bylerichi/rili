import { useState, useEffect } from 'react';
import { tokenService } from '../services/tokens/token-service';
import type { TokenTransaction } from '../services/tokens/token-service';

export function useTransactions(userId: string | undefined) {
  const [transactions, setTransactions] = useState<TokenTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;

    const loadTransactions = async () => {
      try {
        const txs = await tokenService.getTransactions(userId);
        setTransactions(txs);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'Failed to load transactions');
      } finally {
        setLoading(false);
      }
    };

    loadTransactions();
  }, [userId]);

  return { transactions, loading, error };
}