import { useState, useEffect } from 'react';
import { PayPalSDK } from '../services/payment/paypal/sdk';

export function usePayPalSDK() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const sdk = PayPalSDK.getInstance();

    const initSDK = async () => {
      try {
        await sdk.load();
        setReady(true);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load PayPal SDK');
      } finally {
        setLoading(false);
      }
    };

    initSDK();

    return () => {
      sdk.cleanup();
    };
  }, []);

  return { loading, error, ready };
}