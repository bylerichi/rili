import axios from 'axios';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;

export async function generateImage(prompt: string): Promise<string> {
  try {
    const response = await axios.post(
      'https://api.recraft.ai/v1/generate',
      {
        prompt,
        // Configuration de base pour Recraft
        width: 1024,
        height: 1024,
        num_images: 1,
        guidance_scale: 7.5
      },
      {
        headers: {
          'Authorization': `Bearer ${RECRAFT_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    // Vérifier si la réponse contient une URL d'image
    if (!response.data?.imageUrl) {
      throw new Error('Pas d\'URL d\'image dans la réponse');
    }

    return response.data.imageUrl;
  } catch (error) {
    // Éviter de logger l'erreur avec console.error pour prévenir le DataCloneError
    throw new Error(error instanceof Error ? error.message : 'Erreur de génération d\'image');
  }
}