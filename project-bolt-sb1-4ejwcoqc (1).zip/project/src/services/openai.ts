import axios from 'axios';

const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

const SYSTEM_PROMPT = `You are a professional recipe generator that creates recipes with a strict, consistent structure.

Your response MUST follow this EXACT format with these EXACT section markers:

[TITLE]
Recipe name with emojis

[DESCRIPTION]
Brief recipe description

[INGREDIENTS]
- Ingredient 1
- Ingredient 2
...

[INSTRUCTIONS]
1. Step one
2. Step two
...

[HASHTAGS]
#tag1 #tag2 #tag3

[TOP_VIEW_PROMPT]
Detailed prompt for top view image

[MACRO_PROMPT]
Detailed prompt for macro shot`;

export async function generateRecipe(ingredients: string): Promise<string> {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: "gpt-4-turbo-preview",
        messages: [
          {
            role: "system",
            content: SYSTEM_PROMPT
          },
          {
            role: "user",
            content: ingredients
          }
        ],
        temperature: 0.7
      },
      {
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data.choices[0].message.content;
  } catch (error) {
    console.error('Erreur lors de la génération de la recette:', error);
    throw error;
  }
}