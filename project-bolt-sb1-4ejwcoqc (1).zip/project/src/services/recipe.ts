import { auth } from '../lib/auth';
import { storage } from '../lib/storage';
import { generateRecipe } from './openai';
import { generateImage } from './recraft';
import { ValidationError } from '../utils/validation';

export async function processRecipe(recipeName: string) {
  const user = await auth.getUser();
  if (!user) {
    throw new ValidationError('Utilisateur non connecté');
  }

  try {
    // Générer la recette avec ChatGPT
    const recipeText = await generateRecipe(recipeName);
    if (!recipeText) {
      throw new Error('Échec de la génération de la recette');
    }

    const parts = recipeText.split('\n\n');
    if (parts.length < 5) {
      throw new Error('Format de recette invalide');
    }

    const [name, topViewPrompt, closeUpPrompt, ingredients, instructions] = parts;

    // Générer les images en parallèle
    const [topViewImage, closeUpImage] = await Promise.all([
      generateImage(topViewPrompt),
      generateImage(closeUpPrompt)
    ]).catch(() => {
      throw new Error('Échec de la génération des images');
    });

    // Sauvegarder le contenu de la recette
    const recipeContent = `${ingredients}\n\n${instructions}`;
    await storage.saveRecipe(user.id, name, recipeContent);

    // Télécharger et sauvegarder les images
    try {
      const [topViewResponse, closeUpResponse] = await Promise.all([
        fetch(topViewImage),
        fetch(closeUpImage)
      ]);

      if (!topViewResponse.ok || !closeUpResponse.ok) {
        throw new Error('Échec du téléchargement des images');
      }

      const [topViewBuffer, closeUpBuffer] = await Promise.all([
        topViewResponse.arrayBuffer(),
        closeUpResponse.arrayBuffer()
      ]);

      await Promise.all([
        storage.saveImage(user.id, name, Buffer.from(topViewBuffer), 'top-view.jpg'),
        storage.saveImage(user.id, name, Buffer.from(closeUpBuffer), 'close-up.jpg')
      ]);

      return name;
    } catch (error) {
      throw new Error('Erreur lors de la sauvegarde des images');
    }
  } catch (error) {
    if (error instanceof ValidationError) {
      throw error;
    }
    throw new Error(`Erreur lors du traitement de la recette "${recipeName}": ${error.message}`);
  }
}