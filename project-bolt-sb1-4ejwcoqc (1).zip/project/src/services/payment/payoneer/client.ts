import axios from 'axios';
import { PAYONEER_CONFIG } from './config';
import type { PayoneerCheckout } from './types';

class PayoneerClient {
  private baseUrl = PAYONEER_CONFIG.API_URL;
  private merchantId = PAYONEER_CONFIG.MERCHANT_ID;

  async createCheckout(amount: number): Promise<PayoneerCheckout> {
    try {
      const response = await axios.post(`${this.baseUrl}/checkout`, {
        merchant_id: this.merchantId,
        amount,
        currency: PAYONEER_CONFIG.CURRENCY,
        success_url: PAYONEER_CONFIG.SUCCESS_URL,
        cancel_url: PAYONEER_CONFIG.CANCEL_URL
      });

      return {
        redirectUrl: response.data.redirect_url,
        paymentId: response.data.payment_id
      };
    } catch (error) {
      throw new Error('Failed to create Payoneer checkout');
    }
  }
}

export const payoneerClient = new PayoneerClient();