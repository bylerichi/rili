export const PAYONEER_CONFIG = {
  API_URL: import.meta.env.VITE_PAYONEER_API_URL,
  MERCHANT_ID: import.meta.env.VITE_PAYONEER_MERCHANT_ID,
  SUCCESS_URL: `${window.location.origin}/payment/success`,
  CANCEL_URL: `${window.location.origin}/payment/cancel`,
  CURRENCY: 'USD'
} as const;