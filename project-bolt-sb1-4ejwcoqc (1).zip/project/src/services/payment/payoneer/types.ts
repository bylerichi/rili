export interface PayoneerPayment {
  id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed';
}

export interface PayoneerCheckout {
  redirectUrl: string;
  paymentId: string;
}