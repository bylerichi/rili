import { z } from 'zod';

export const paypalConfigSchema = z.object({
  clientId: z.string().min(1, 'PayPal Client ID is required'),
  clientSecret: z.string().min(1, 'PayPal Client Secret is required'),
  sandbox: z.boolean(),
  currency: z.literal('USD')
});

export type PayPalConfig = z.infer<typeof paypalConfigSchema>;