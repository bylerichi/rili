export const PAYPAL_CONSTANTS = {
  SCRIPT_ID: 'paypal-sdk',
  CURRENCY: 'USD',
  SANDBOX_URL: 'https://api-m.sandbox.paypal.com',
  LIVE_URL: 'https://api-m.paypal.com'
} as const;