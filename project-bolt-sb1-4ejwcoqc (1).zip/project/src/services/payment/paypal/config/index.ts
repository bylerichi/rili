import { z } from 'zod';
import { PAYPAL_CONSTANTS } from './constants';

// Configuration schema
const paypalConfigSchema = z.object({
  clientId: z.string().min(1, 'PayPal Client ID is required'),
  clientSecret: z.string().min(1, 'PayPal Client Secret is required'),
  sandbox: z.boolean(),
  currency: z.literal('USD')
});

export type PayPalConfig = z.infer<typeof paypalConfigSchema>;

// Get validated configuration
export function getPayPalConfig(): PayPalConfig {
  const config = {
    clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
    clientSecret: import.meta.env.VITE_PAYPAL_CLIENT_SECRET,
    sandbox: import.meta.env.VITE_PAYPAL_SANDBOX === 'true',
    currency: PAYPAL_CONSTANTS.CURRENCY
  };

  return paypalConfigSchema.parse(config);
}

// Get API URL based on environment
export function getPayPalApiUrl(): string {
  const config = getPayPalConfig();
  return config.sandbox ? PAYPAL_CONSTANTS.SANDBOX_URL : PAYPAL_CONSTANTS.LIVE_URL;
}

export { PAYPAL_CONSTANTS } from './constants';