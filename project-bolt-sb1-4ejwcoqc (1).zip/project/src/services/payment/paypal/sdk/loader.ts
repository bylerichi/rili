import { PayPalConfigError } from '../errors';
import { getPayPalConfig } from '../config';

export class PayPalSDKLoader {
  private static instance: PayPalSDKLoader;
  private loadPromise: Promise<void> | null = null;
  private readonly config = getPayPalConfig();

  private constructor() {}

  static getInstance(): PayPalSDKLoader {
    if (!PayPalSDKLoader.instance) {
      PayPalSDKLoader.instance = new PayPalSDKLoader();
    }
    return PayPalSDKLoader.instance;
  }

  load(): Promise<void> {
    if (this.loadPromise) {
      return this.loadPromise;
    }

    this.loadPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = `https://www.paypal.com/sdk/js?client-id=${this.config.clientId}&currency=${this.config.currency}`;
      script.async = true;

      script.onload = () => {
        if (window.paypal) {
          resolve();
        } else {
          reject(new PayPalConfigError('PayPal SDK failed to initialize'));
        }
      };

      script.onerror = () => {
        reject(new PayPalConfigError('Failed to load PayPal SDK'));
      };

      document.body.appendChild(script);
    });

    return this.loadPromise;
  }

  cleanup(): void {
    const scripts = document.querySelectorAll('script[src*="paypal.com/sdk/js"]');
    scripts.forEach(script => script.remove());
    this.loadPromise = null;
  }
}