import { PayPalSDKLoader } from './loader';

declare global {
  interface Window {
    paypal?: any;
  }
}

export const PayPalSDK = PayPalSDKLoader;