export class PayPalError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PayPalError';
  }
}

export class PayPalConfigError extends PayPalError {
  constructor(message: string) {
    super(message);
    this.name = 'PayPalConfigError';
  }
}

export class PayPalAPIError extends PayPalError {
  constructor(message: string) {
    super(message);
    this.name = 'PayPalAPIError';
  }
}