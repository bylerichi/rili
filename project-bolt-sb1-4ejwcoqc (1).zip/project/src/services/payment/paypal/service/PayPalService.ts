import { paypalApi } from '../api';
import { PayPalAPIError } from '../errors';
import type { TokenPackage } from '../../types';

export class PayPalService {
  async createOrder(pkg: TokenPackage): Promise<string> {
    try {
      const order = await paypalApi.createOrder(pkg.price);
      return order.id;
    } catch (error) {
      throw new PayPalAPIError(
        error instanceof Error ? error.message : 'Failed to create PayPal order'
      );
    }
  }

  async capturePayment(orderId: string): Promise<void> {
    try {
      await paypalApi.capturePayment(orderId);
    } catch (error) {
      throw new PayPalAPIError(
        error instanceof Error ? error.message : 'Failed to capture payment'
      );
    }
  }
}