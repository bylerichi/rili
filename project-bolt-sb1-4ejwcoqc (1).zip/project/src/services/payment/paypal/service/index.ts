import { PayPalService } from './PayPalService';

export const paypalService = new PayPalService();