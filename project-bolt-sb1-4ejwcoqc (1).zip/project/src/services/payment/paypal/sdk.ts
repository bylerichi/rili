import { PayPalConfigError } from './errors';
import { getPayPalConfig, PAYPAL_CONSTANTS } from './config';

declare global {
  interface Window {
    paypal?: any;
  }
}

export class PayPalSDK {
  private static instance: PayPalSDK;
  private loadPromise: Promise<void> | null = null;
  private readonly config = getPayPalConfig();

  private constructor() {}

  static getInstance(): PayPalSDK {
    if (!PayPalSDK.instance) {
      PayPalSDK.instance = new PayPalSDK();
    }
    return PayPalSDK.instance;
  }

  load(): Promise<void> {
    if (this.loadPromise) {
      return this.loadPromise;
    }

    this.loadPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = `https://www.paypal.com/sdk/js?client-id=${this.config.clientId}&currency=${this.config.currency}`;
      script.async = true;

      script.onload = () => {
        if (window.paypal) {
          resolve();
        } else {
          reject(new PayPalConfigError('PayPal SDK failed to initialize'));
        }
      };

      script.onerror = () => {
        reject(new PayPalConfigError('Failed to load PayPal SDK'));
      };

      document.body.appendChild(script);
    });

    return this.loadPromise;
  }

  cleanup(): void {
    const scripts = document.querySelectorAll('script[src*="paypal.com/sdk/js"]');
    scripts.forEach(script => script.remove());
    this.loadPromise = null;
  }
}