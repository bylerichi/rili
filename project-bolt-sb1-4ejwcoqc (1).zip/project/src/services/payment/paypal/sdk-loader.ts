import { PayPalConfigError } from './errors';
import { PAYPAL_CONFIG } from './config';

export class PayPalSDKLoader {
  private static instance: PayPalSDKLoader;
  private loadPromise: Promise<void> | null = null;

  private constructor() {}

  static getInstance(): PayPalSDKLoader {
    if (!PayPalSDKLoader.instance) {
      PayPalSDKLoader.instance = new PayPalSDKLoader();
    }
    return PayPalSDKLoader.instance;
  }

  load(): Promise<void> {
    if (this.loadPromise) {
      return this.loadPromise;
    }

    const clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID;
    if (!clientId) {
      return Promise.reject(new PayPalConfigError('PayPal Client ID not found'));
    }

    this.loadPromise = new Promise((resolve, reject) => {
      if (document.getElementById(PAYPAL_CONFIG.SCRIPT_ID)) {
        resolve();
        return;
      }

      const script = document.createElement('script');
      script.id = PAYPAL_CONFIG.SCRIPT_ID;
      script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=${PAYPAL_CONFIG.CURRENCY}`;
      script.async = true;

      script.onload = () => {
        if (window.paypal) {
          resolve();
        } else {
          reject(new PayPalConfigError('PayPal SDK failed to initialize'));
        }
      };

      script.onerror = () => {
        reject(new PayPalConfigError('Failed to load PayPal SDK'));
      };

      document.body.appendChild(script);
    });

    return this.loadPromise;
  }

  cleanup(): void {
    const script = document.getElementById(PAYPAL_CONFIG.SCRIPT_ID);
    if (script) {
      document.body.removeChild(script);
    }
    this.loadPromise = null;
  }
}