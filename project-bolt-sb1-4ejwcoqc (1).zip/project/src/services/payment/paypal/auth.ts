import { PayPalConfigError } from './errors';

export class PayPalAuth {
  private static accessToken: string | null = null;
  private static expiresAt: number = 0;

  static async getAccessToken(): Promise<string> {
    if (this.isTokenValid()) {
      return this.accessToken!;
    }

    const clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID;
    const clientSecret = import.meta.env.VITE_PAYPAL_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
      throw new PayPalConfigError('PayPal credentials not found');
    }

    try {
      const response = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Accept-Language': 'en_US',
          'Authorization': `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
        },
        body: 'grant_type=client_credentials'
      });

      if (!response.ok) {
        throw new Error('Failed to get access token');
      }

      const data = await response.json();
      this.accessToken = data.access_token;
      this.expiresAt = Date.now() + (data.expires_in * 1000);

      return this.accessToken;
    } catch (error) {
      throw new PayPalConfigError('Failed to authenticate with PayPal');
    }
  }

  private static isTokenValid(): boolean {
    return !!(this.accessToken && Date.now() < this.expiresAt);
  }

  static clearToken(): void {
    this.accessToken = null;
    this.expiresAt = 0;
  }
}