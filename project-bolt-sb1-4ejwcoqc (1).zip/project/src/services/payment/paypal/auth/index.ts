import { PayPalConfigError } from '../errors';
import { getPayPalConfig } from '../config';

export class PayPalAuth {
  private static accessToken: string | null = null;
  private static expiresAt: number = 0;
  private static readonly config = getPayPalConfig();

  static async getAccessToken(): Promise<string> {
    if (this.isTokenValid()) {
      return this.accessToken!;
    }

    try {
      const auth = btoa(`${this.config.clientId}:${this.config.clientSecret}`);
      const response = await fetch(
        `${this.config.sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com'}/v1/oauth2/token`,
        {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Authorization': `Basic ${auth}`,
          },
          body: 'grant_type=client_credentials'
        }
      );

      if (!response.ok) {
        throw new Error('Failed to get access token');
      }

      const data = await response.json();
      this.accessToken = data.access_token;
      this.expiresAt = Date.now() + (data.expires_in * 1000);

      return this.accessToken;
    } catch (error) {
      throw new PayPalConfigError('Failed to authenticate with PayPal');
    }
  }

  private static isTokenValid(): boolean {
    return !!(this.accessToken && Date.now() < this.expiresAt);
  }

  static clearToken(): void {
    this.accessToken = null;
    this.expiresAt = 0;
  }
}