import { z } from 'zod';

// Configuration schema
const paypalConfigSchema = z.object({
  clientId: z.string().min(1, 'PayPal Client ID is required'),
  clientSecret: z.string().min(1, 'PayPal Client Secret is required'),
  sandbox: z.boolean(),
  currency: z.literal('USD')
});

export type PayPalConfig = z.infer<typeof paypalConfigSchema>;

// Get validated configuration
export function getPayPalConfig(): PayPalConfig {
  const config = {
    clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
    clientSecret: import.meta.env.VITE_PAYPAL_CLIENT_SECRET,
    sandbox: import.meta.env.VITE_PAYPAL_SANDBOX === 'true',
    currency: 'USD' as const
  };

  return paypalConfigSchema.parse(config);
}

export const PAYPAL_CONFIG = {
  SCRIPT_ID: 'paypal-sdk',
  CURRENCY: 'USD',
  BASE_URL: import.meta.env.VITE_PAYPAL_SANDBOX === 'true' 
    ? 'https://api-m.sandbox.paypal.com'
    : 'https://api-m.paypal.com'
} as const;