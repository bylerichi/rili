import { PayPalAuth } from './auth';
import { PayPalAPIError } from './errors';
import { getPayPalConfig } from './config';
import type { PayPalOrder, PayPalCaptureResponse } from './types';

export class PayPalAPI {
  private readonly config = getPayPalConfig();
  private readonly baseUrl = this.config.sandbox 
    ? 'https://api-m.sandbox.paypal.com' 
    : 'https://api-m.paypal.com';

  async createOrder(amount: number): Promise<PayPalOrder> {
    try {
      const accessToken = await PayPalAuth.getAccessToken();
      
      const response = await fetch(`${this.baseUrl}/v2/checkout/orders`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          intent: 'CAPTURE',
          purchase_units: [{
            amount: {
              currency_code: this.config.currency,
              value: amount.toFixed(2)
            }
          }]
        })
      });

      if (!response.ok) {
        throw new PayPalAPIError('Failed to create PayPal order');
      }

      return response.json();
    } catch (error) {
      throw new PayPalAPIError(
        error instanceof Error ? error.message : 'Failed to create PayPal order'
      );
    }
  }

  async capturePayment(orderId: string): Promise<PayPalCaptureResponse> {
    try {
      const accessToken = await PayPalAuth.getAccessToken();

      const response = await fetch(
        `${this.baseUrl}/v2/checkout/orders/${orderId}/capture`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      if (!response.ok) {
        throw new PayPalAPIError('Failed to capture payment');
      }

      return response.json();
    } catch (error) {
      throw new PayPalAPIError(
        error instanceof Error ? error.message : 'Failed to capture payment'
      );
    }
  }
}