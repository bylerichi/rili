import { PAYPAL_CONFIG } from './config';
import type { TokenPackage } from '../types';

class PayPalService {
  private readonly clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID;

  async createOrder(pkg: TokenPackage): Promise<string> {
    try {
      const response = await fetch(`${PAYPAL_CONFIG.BASE_URL}/v2/checkout/orders`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.clientId}`
        },
        body: JSON.stringify({
          intent: 'CAPTURE',
          purchase_units: [{
            amount: {
              currency_code: PAYPAL_CONFIG.CURRENCY,
              value: pkg.price.toFixed(2)
            },
            description: pkg.description
          }]
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create PayPal order');
      }

      const data = await response.json();
      return data.id;
    } catch (error) {
      throw new Error('Failed to create PayPal order');
    }
  }

  async capturePayment(orderId: string): Promise<void> {
    try {
      const response = await fetch(
        `${PAYPAL_CONFIG.BASE_URL}/v2/checkout/orders/${orderId}/capture`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.clientId}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to capture payment');
      }
    } catch (error) {
      throw new Error('Failed to capture payment');
    }
  }
}

export const paypalService = new PayPalService();