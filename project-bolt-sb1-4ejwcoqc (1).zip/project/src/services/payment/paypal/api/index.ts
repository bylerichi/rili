import { PayPalClient } from './client';

export const paypalApi = new PayPalClient();