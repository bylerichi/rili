import { PAYPAL_CONFIG } from './config';

export function loadPayPalScript(url: string): Promise<void> {
  return new Promise((resolve, reject) => {
    // Check if script already exists
    if (document.getElementById(PAYPAL_CONFIG.SCRIPT_ID)) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.id = PAYPAL_CONFIG.SCRIPT_ID;
    script.src = url;
    script.async = true;

    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load PayPal SDK'));

    document.body.appendChild(script);
  });
}

export function removePayPalScript(): void {
  const script = document.getElementById(PAYPAL_CONFIG.SCRIPT_ID);
  if (script) {
    document.body.removeChild(script);
  }
}