import { useState, useCallback } from 'react';
import { paypalService } from '../service';
import type { TokenPackage } from '../../types';

export function usePayPalOrder() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [orderId, setOrderId] = useState<string | null>(null);

  const createOrder = useCallback(async (pkg: TokenPackage) => {
    if (loading) return;

    setLoading(true);
    setError(null);

    try {
      const id = await paypalService.createOrder(pkg);
      setOrderId(id);
      return id;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create order');
      return null;
    } finally {
      setLoading(false);
    }
  }, [loading]);

  return {
    loading,
    error,
    orderId,
    createOrder
  };
}