import { useState, useEffect } from 'react';
import { getPayPalConfig } from '../config';
import type { PayPalConfig } from '../config';

export function usePayPalConfig() {
  const [config, setConfig] = useState<PayPalConfig | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const paypalConfig = getPayPalConfig();
      setConfig(paypalConfig);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load PayPal configuration');
    }
  }, []);

  return { config, error };
}