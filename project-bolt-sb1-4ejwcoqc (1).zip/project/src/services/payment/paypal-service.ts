import { supabase } from '../../lib/supabase';
import type { PaymentTransaction } from './types';

class PayPalService {
  private readonly clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID;
  private readonly secret = import.meta.env.VITE_PAYPAL_SECRET;

  private async getAccessToken(): Promise<string> {
    const auth = btoa(`${this.clientId}:${this.secret}`);
    const response = await fetch('https://api-m.sandbox.paypal.com/v1/oauth2/token', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Authorization': `Basic ${auth}`,
      },
      body: 'grant_type=client_credentials'
    });

    if (!response.ok) {
      throw new Error('Failed to get PayPal access token');
    }

    const data = await response.json();
    return data.access_token;
  }

  async createOrder(tokenAmount: number, priceInUSD: number): Promise<string> {
    try {
      const accessToken = await this.getAccessToken();
      const response = await fetch('https://api-m.sandbox.paypal.com/v2/checkout/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
          'PayPal-Request-Id': crypto.randomUUID()
        },
        body: JSON.stringify({
          intent: 'CAPTURE',
          purchase_units: [{
            amount: {
              currency_code: 'USD',
              value: priceInUSD.toFixed(2)
            },
            description: `${tokenAmount} Tokens Purchase`,
            custom_id: tokenAmount.toString()
          }]
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create PayPal order');
      }

      const data = await response.json();
      return data.id;
    } catch (error) {
      console.error('PayPal create order error:', error);
      throw new Error('Failed to create PayPal order');
    }
  }

  async capturePayment(orderId: string): Promise<PaymentTransaction> {
    try {
      const accessToken = await this.getAccessToken();
      const response = await fetch(`https://api-m.sandbox.paypal.com/v2/checkout/orders/${orderId}/capture`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to capture PayPal payment');
      }

      const data = await response.json();
      
      return {
        id: data.id,
        status: data.status,
        amount: parseFloat(data.purchase_units[0].amount.value),
        tokenAmount: parseInt(data.purchase_units[0].custom_id),
        provider: 'PAYPAL',
        metadata: {
          paypalOrderId: data.id,
          payerEmail: data.payer?.email_address
        }
      };
    } catch (error) {
      console.error('PayPal capture payment error:', error);
      throw new Error('Failed to capture PayPal payment');
    }
  }

  async processPayment(userId: string, transaction: PaymentTransaction): Promise<void> {
    const { error } = await supabase.rpc('add_tokens', {
      p_user_id: userId,
      p_amount: transaction.tokenAmount,
      p_description: `PayPal purchase - Order ID: ${transaction.id}`
    });

    if (error) {
      console.error('Token processing error:', error);
      throw new Error('Failed to process token purchase');
    }
  }
}

export const paypalService = new PayPalService();