export interface PaymentTransaction {
  id: string;
  status: 'COMPLETED' | 'FAILED' | 'PENDING';
  amount: number;
  tokenAmount: number;
  provider: 'PAYPAL';
  metadata: Record<string, any>;
}

export interface TokenPackage {
  id: string;
  amount: number;
  price: number;
  currency: string;
  description: string;
}

export interface PaymentResult {
  success: boolean;
  transactionId?: string;
  error?: string;
}