export const TOKEN_PACKAGES = [
  {
    id: 'basic',
    amount: 10,
    price: 5,
    currency: 'USD',
    description: 'Basic Package - 10 Tokens'
  },
  {
    id: 'starter',
    amount: 25,
    price: 10,
    currency: 'USD',
    description: 'Starter Package - 25 Tokens'
  },
  {
    id: 'pro',
    amount: 50,
    price: 18,
    currency: 'USD',
    description: 'Pro Package - 50 Tokens'
  },
  {
    id: 'enterprise',
    amount: 100,
    price: 30,
    currency: 'USD',
    description: 'Enterprise Package - 100 Tokens'
  }
] as const;