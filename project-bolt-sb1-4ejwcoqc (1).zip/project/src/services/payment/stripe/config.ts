export const STRIPE_CONFIG = {
  PUBLIC_KEY: import.meta.env.VITE_STRIPE_PUBLIC_KEY,
  API_URL: 'https://lkwvbzcwzyoifgxfxfmd.supabase.co/functions/v1',
  SUCCESS_URL: `${window.location.origin}/payment/success`,
  CANCEL_URL: `${window.location.origin}/payment/cancel`,
  CURRENCY: 'USD'
} as const;