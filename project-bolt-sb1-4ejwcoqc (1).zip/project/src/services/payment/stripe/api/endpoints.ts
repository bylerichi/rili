export const STRIPE_ENDPOINTS = {
  // Use relative URL for Edge Function
  CHECKOUT: '/api/create-checkout-session'
} as const;