import { STRIPE_ENDPOINTS } from './endpoints';
import { makeStripeRequest } from './request';
import { StripeSessionError } from '../errors';
import type { StripeCheckoutSession } from '../types';

export async function createCheckoutSession(
  priceId: string
): Promise<StripeCheckoutSession> {
  try {
    const data = await makeStripeRequest<{
      sessionId: string;
      url: string;
    }>(STRIPE_ENDPOINTS.CHECKOUT, { priceId });

    return {
      id: data.sessionId,
      url: data.url
    };
  } catch (error) {
    console.error('Stripe session error:', error);
    throw new StripeSessionError(
      error instanceof Error ? error.message : 'Failed to create checkout session'
    );
  }
}