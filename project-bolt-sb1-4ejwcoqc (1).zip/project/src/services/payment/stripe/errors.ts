export class StripeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'StripeError';
  }
}

export class StripeSessionError extends StripeError {
  constructor(message: string) {
    super(message);
    this.name = 'StripeSessionError';
  }
}

export class StripeRedirectError extends StripeError {
  constructor(message: string) {
    super(message);
    this.name = 'StripeRedirectError';
  }
}