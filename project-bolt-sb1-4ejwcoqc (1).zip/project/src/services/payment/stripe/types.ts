export interface StripeCheckoutSession {
  id: string;
  url: string;
}

export interface TokenPackage {
  id: string;
  amount: number;
  price: number;
  currency: string;
  description: string;
}