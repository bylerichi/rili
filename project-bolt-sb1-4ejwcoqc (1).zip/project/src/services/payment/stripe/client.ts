import { createCheckoutSession } from './api';
import { StripeRedirectError } from './errors';
import type { TokenPackage } from '../types';

class StripeClient {
  async redirectToCheckout(pkg: TokenPackage): Promise<void> {
    try {
      const session = await createCheckoutSession(pkg.id);

      if (!session?.url) {
        throw new StripeRedirectError('Invalid checkout session');
      }

      // Use window.location.href for consistent behavior
      window.location.href = session.url;
    } catch (error) {
      console.error('Stripe redirect error:', error);
      throw new StripeRedirectError(
        error instanceof Error ? error.message : 'Failed to redirect to checkout'
      );
    }
  }
}

export const stripeClient = new StripeClient();