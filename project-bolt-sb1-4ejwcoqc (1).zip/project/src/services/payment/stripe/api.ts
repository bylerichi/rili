import { STRIPE_CONFIG } from './config';
import { StripeSessionError } from './errors';
import type { StripeCheckoutSession } from './types';

export async function createCheckoutSession(priceId: string): Promise<StripeCheckoutSession> {
  try {
    // Use the correct Edge Function URL
    const response = await fetch(
      `${STRIPE_CONFIG.API_URL}/create-checkout-session`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          priceId,
          successUrl: STRIPE_CONFIG.SUCCESS_URL,
          cancelUrl: STRIPE_CONFIG.CANCEL_URL
        }),
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new StripeSessionError(errorData.error || 'Failed to create checkout session');
    }

    const data = await response.json();
    
    if (!data.url || !data.sessionId) {
      throw new StripeSessionError('Invalid response from payment server');
    }

    return { 
      id: data.sessionId,
      url: data.url
    };
  } catch (error) {
    console.error('Stripe session error:', error);
    throw new StripeSessionError(
      error instanceof Error ? error.message : 'Failed to create checkout session'
    );
  }
}