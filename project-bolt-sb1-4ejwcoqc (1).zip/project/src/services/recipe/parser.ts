import { RecipeParts } from './types';

function extractSection(text: string, marker: string): string {
  const pattern = new RegExp(`\\[${marker}\\]\\n(.*?)(?=\\n\\[|$)`, 's');
  const match = text.match(pattern);
  
  if (!match || !match[1]) {
    throw new Error(`Section [${marker}] introuvable ou vide`);
  }
  
  return match[1].trim();
}

export function parseRecipeText(text: string): RecipeParts {
  try {
    const normalizedText = text.replace(/\r\n/g, '\n').trim();

    return {
      title: extractSection(normalizedText, 'TITLE'),
      description: extractSection(normalizedText, 'DESCRIPTION'),
      ingredients: extractSection(normalizedText, 'INGREDIENTS'),
      instructions: extractSection(normalizedText, 'INSTRUCTIONS'),
      imagePrompt: extractSection(normalizedText, 'TOP_VIEW_PROMPT'),
      macroPrompt: extractSection(normalizedText, 'MACRO_PROMPT'),
      hashtags: extractSection(normalizedText, 'HASHTAGS')
    };
  } catch (error) {
    throw new Error(`Erreur de parsing: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
  }
}