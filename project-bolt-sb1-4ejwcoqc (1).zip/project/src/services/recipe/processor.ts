import { generateRecipe } from '../openai';
import { generateImage } from '../recraft/client';
import { parseRecipeText } from './parser';
import { GeneratedFiles } from './types';

export async function processRecipe(recipeName: string): Promise<GeneratedFiles> {
  try {
    // Generate text with ChatGPT
    const recipeText = await generateRecipe(recipeName);
    const parts = parseRecipeText(recipeText);
    
    // Create text file
    const recipeContent = `${parts.title}\n\n${parts.description}\n\n${parts.ingredients}\n\n${parts.instructions}`;
    
    // Generate image with Recraft
    const imageUrl = await generateImage(parts.imagePrompt);
    
    return {
      recipeText: recipeContent,
      imageUrl
    };
  } catch (error) {
    throw new Error(`Generation error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}