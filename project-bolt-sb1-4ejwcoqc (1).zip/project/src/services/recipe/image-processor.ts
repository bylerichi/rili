import { generateImage } from '../recraft/client';
import { delay } from '../../utils/delay';
import { logError } from '../../utils/error';

const IMAGE_GENERATION_DELAY = 2000; // 2 secondes entre chaque génération

export async function generateRecipeImages(
  topViewPrompt: string,
  closeUpPrompt: string
): Promise<{ topViewUrl: string; closeUpUrl: string }> {
  try {
    // Générer la première image
    const topViewUrl = await generateImage(topViewPrompt);
    
    // Attendre avant de générer la deuxième image
    await delay(IMAGE_GENERATION_DELAY);
    
    // Générer la deuxième image
    const closeUpUrl = await generateImage(closeUpPrompt);

    return { topViewUrl, closeUpUrl };
  } catch (error) {
    logError('generateRecipeImages', error);
    throw new Error('Échec de la génération des images');
  }
}