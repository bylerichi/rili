import { delay } from '../../utils/delay';
import { logError } from '../../utils/error';
import { ImageGenerationError } from './errors';

const QUEUE_DELAY = 20000; // 20 second delay between requests
let lastRequestTime = 0;

async function waitForNextSlot(): Promise<void> {
  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;
  
  if (timeSinceLastRequest < QUEUE_DELAY) {
    const waitTime = QUEUE_DELAY - timeSinceLastRequest;
    await delay(waitTime);
  }
  
  lastRequestTime = Date.now();
}

export async function queueImageGeneration<T>(
  generator: () => Promise<T>,
  onProgress?: (progress: number) => void
): Promise<T> {
  try {
    await waitForNextSlot();
    
    // Update progress while waiting
    if (onProgress) {
      const startTime = Date.now();
      const progressInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min((elapsed / QUEUE_DELAY) * 100, 100);
        onProgress(progress);
      }, 100);

      const result = await generator();
      clearInterval(progressInterval);
      return result;
    }

    return await generator();
  } catch (error) {
    logError('queueImageGeneration', error);
    throw new ImageGenerationError(
      error instanceof Error ? error.message : 'Erreur de génération d\'image'
    );
  }
}