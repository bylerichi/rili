export interface RecipeParts {
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
  imagePrompt: string;
  macroPrompt: string;
  hashtags: string;
}

export interface GeneratedFiles {
  recipeText: string;
  imageUrl: string;
}