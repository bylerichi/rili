import { storage } from '../../lib/storage';
import { RecipeParsingError } from './errors';
import type { RecipeParts } from './types';

export async function saveRecipeText(
  userId: string,
  recipeParts: RecipeParts
): Promise<void> {
  try {
    const { name, ingredients, instructions } = recipeParts;
    const content = `${ingredients}\n\n${instructions}`;
    
    await storage.saveRecipe(userId, name, content);
  } catch (error) {
    throw new RecipeParsingError(
      `Erreur lors de la sauvegarde du texte de la recette: ${error.message}`
    );
  }
}