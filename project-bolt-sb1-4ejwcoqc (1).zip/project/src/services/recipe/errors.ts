export class RecipeGenerationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RecipeGenerationError';
  }
}

export class RecipeParsingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RecipeParsingError';
  }
}

export class ImageGenerationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ImageGenerationError';
  }
}