import { generateRecipe } from '../openai';
import { parseRecipeText } from './parser';
import type { RecipeParts } from './types';

class RecipeService {
  async generateRecipe(recipeName: string): Promise<RecipeParts> {
    try {
      // Generate recipe text using OpenAI
      const recipeText = await generateRecipe(recipeName);
      
      // Parse the generated text
      const parsed = parseRecipeText(recipeText);
      
      return parsed;
    } catch (error) {
      throw new Error(`Failed to generate recipe: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export const recipeService = new RecipeService();