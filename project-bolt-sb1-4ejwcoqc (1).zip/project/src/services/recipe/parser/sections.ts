export interface RecipeSection {
  title: string;
  body: string;
  hashtags: string;
  topViewPrompt: string;
  macroPrompt: string;
}

export function extractSections(text: string): RecipeSection {
  const sections = {
    title: extractSection(text, 'Recipe Title'),
    body: extractSection(text, 'Recipe Body'),
    hashtags: extractSection(text, 'Hashtags'),
    topViewPrompt: extractSection(text, 'Text Image Prompt Instruction'),
    macroPrompt: extractSection(text, 'Macro Shot Prompt Instruction')
  };

  validateSections(sections);
  return sections;
}

function extractSection(text: string, sectionName: string): string {
  const pattern = new RegExp(`\\*\\*\\d+\\. ${sectionName}:\\*\\*\\n(.*?)(?=\\n\\*\\*\\d+\\.|$)`, 's');
  const match = text.match(pattern);
  return match?.[1]?.trim() ?? '';
}

function validateSections(sections: RecipeSection): void {
  const missingFields = Object.entries(sections)
    .filter(([_, value]) => !value)
    .map(([key]) => key);

  if (missingFields.length > 0) {
    throw new Error(`Sections manquantes: ${missingFields.join(', ')}`);
  }
}