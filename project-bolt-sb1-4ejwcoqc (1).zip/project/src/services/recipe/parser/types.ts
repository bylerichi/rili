export interface RecipeSection {
  title: string;
  body: string;
  hashtags: string;
  topViewPrompt: string;
  macroPrompt: string;
}

export interface RecipeBody {
  description: string;
  ingredients: string;
  instructions: string;
}

export interface ParsedRecipe {
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
  imagePrompt: string;
  macroPrompt: string;
  hashtags: string;
}