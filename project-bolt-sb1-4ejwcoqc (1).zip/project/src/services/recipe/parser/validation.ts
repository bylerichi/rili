import { RecipeSection, RecipeBody } from './types';

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export function validateSection(
  section: string | null | undefined,
  sectionName: string
): asserts section is string {
  if (!section?.trim()) {
    throw new ValidationError(`Section "${sectionName}" manquante ou vide`);
  }
}

export function validateRecipeStructure(sections: Partial<RecipeSection>): void {
  const requiredSections = [
    'title',
    'body',
    'topViewPrompt',
    'macroPrompt'
  ] as const;

  for (const section of requiredSections) {
    validateSection(sections[section], section);
  }
}

export function validateRecipeBody(body: Partial<RecipeBody>): void {
  const requiredParts = [
    'description',
    'ingredients',
    'instructions'
  ] as const;

  for (const part of requiredParts) {
    validateSection(body[part], part);
  }
}