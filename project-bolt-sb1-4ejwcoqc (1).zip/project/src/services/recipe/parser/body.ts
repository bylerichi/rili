export interface RecipeBody {
  description: string;
  ingredients: string;
  instructions: string;
}

export function parseRecipeBody(bodyText: string): RecipeBody {
  const description = extractBodySection(bodyText, 'Description');
  const ingredients = extractBodySection(bodyText, 'Ingredients');
  const instructions = extractBodySection(bodyText, 'Instructions');

  validateBody({ description, ingredients, instructions });
  return { description, ingredients, instructions };
}

function extractBodySection(text: string, sectionName: string): string {
  const pattern = new RegExp(`${sectionName}:\\n(.*?)(?=\\n\\n[A-Z]|$)`, 's');
  const match = text.match(pattern);
  return match?.[1]?.trim() ?? '';
}

function validateBody(body: RecipeBody): void {
  const missingFields = Object.entries(body)
    .filter(([_, value]) => !value)
    .map(([key]) => key);

  if (missingFields.length > 0) {
    throw new Error(`Sections du corps manquantes: ${missingFields.join(', ')}`);
  }
}