import { normalizeText, extractBetweenMarkers } from '../../../utils/text';
import { ValidationError, validateRecipeStructure, validateRecipeBody } from './validation';
import type { RecipeSection, RecipeBody, ParsedRecipe } from './types';

function extractSections(text: string): RecipeSection {
  const normalizedText = normalizeText(text);
  
  const sections: Partial<RecipeSection> = {
    title: extractBetweenMarkers(
      normalizedText,
      '**1. Recipe Title:**\n',
      '**2. Recipe Body:**'
    ),
    body: extractBetweenMarkers(
      normalizedText,
      '**2. Recipe Body:**\n',
      '**3. Hashtags:**'
    ),
    hashtags: extractBetweenMarkers(
      normalizedText,
      '**3. Hashtags:**\n',
      '**4. Text Image Prompt Instruction:**'
    ),
    topViewPrompt: extractBetweenMarkers(
      normalizedText,
      '**4. Text Image Prompt Instruction:**\n',
      '**5. Macro Shot Prompt Instruction:**'
    ),
    macroPrompt: extractBetweenMarkers(
      normalizedText,
      '**5. Macro Shot Prompt Instruction:**\n',
      '**6. Keyword:**'
    )
  };

  validateRecipeStructure(sections);
  return sections as RecipeSection;
}

function parseBody(bodyText: string): RecipeBody {
  const normalizedBody = normalizeText(bodyText);
  
  const body: Partial<RecipeBody> = {
    description: extractBetweenMarkers(
      normalizedBody,
      'Description:\n',
      'Ingredients:'
    ),
    ingredients: extractBetweenMarkers(
      normalizedBody,
      'Ingredients:\n',
      'Instructions:'
    ),
    instructions: extractBetweenMarkers(
      normalizedBody,
      'Instructions:\n'
    )
  };

  validateRecipeBody(body);
  return body as RecipeBody;
}

export function parseRecipeText(text: string): ParsedRecipe {
  try {
    const sections = extractSections(text);
    const body = parseBody(sections.body);

    return {
      title: sections.title,
      description: body.description,
      ingredients: body.ingredients,
      instructions: body.instructions,
      imagePrompt: sections.topViewPrompt,
      macroPrompt: sections.macroPrompt,
      hashtags: sections.hashtags
    };
  } catch (error) {
    if (error instanceof ValidationError) {
      throw error;
    }
    throw new Error(`Erreur de parsing: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
  }
}