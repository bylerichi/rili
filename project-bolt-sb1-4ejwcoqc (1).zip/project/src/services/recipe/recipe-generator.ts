import { generateRecipe } from '../openai';
import { parseRecipeText } from './parser';
import { GeneratedRecipe } from './types';
import { RecipeGenerationError } from './errors';

export async function generateAndParseRecipe(recipeName: string): Promise<GeneratedRecipe> {
  try {
    const text = await generateRecipe(recipeName);
    if (!text) {
      throw new RecipeGenerationError('La génération de la recette a échoué');
    }

    const parts = parseRecipeText(text);
    return { text, parts };
  } catch (error) {
    if (error instanceof RecipeGenerationError) {
      throw error;
    }
    throw new RecipeGenerationError(
      error instanceof Error ? error.message : 'Erreur lors de la génération de la recette'
    );
  }
}