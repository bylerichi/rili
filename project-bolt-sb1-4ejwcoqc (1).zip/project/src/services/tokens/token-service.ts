import { supabase } from '../../lib/supabase';
import type { TokenBalance, TokenTransaction } from './types';

class TokenService {
  async getBalance(userId: string): Promise<TokenBalance> {
    // First try to get existing balance
    const { data, error } = await supabase
      .from('user_tokens')
      .select('balance, updated_at')
      .eq('user_id', userId)
      .maybeSingle(); // Use maybeSingle instead of single to handle no rows case

    if (error) {
      throw new Error('Failed to get token balance');
    }

    // If no record exists, return default values
    if (!data) {
      // Initialize with 0 balance for new users
      await this.initializeBalance(userId);
      return {
        balance: 0,
        updatedAt: new Date().toISOString()
      };
    }

    return {
      balance: data.balance,
      updatedAt: data.updated_at
    };
  }

  private async initializeBalance(userId: string): Promise<void> {
    const { error } = await supabase
      .from('user_tokens')
      .insert([
        { user_id: userId, balance: 0 }
      ]);

    if (error) {
      console.error('Failed to initialize token balance:', error);
      // Don't throw here as this is a background initialization
    }
  }

  async addTokens(userId: string, amount: number, description: string): Promise<void> {
    if (amount <= 0) {
      throw new Error('Token amount must be positive');
    }

    const { error } = await supabase.rpc('add_tokens', {
      p_user_id: userId,
      p_amount: amount,
      p_description: description
    });

    if (error) {
      console.error('Token addition error:', error);
      throw new Error('Failed to add tokens');
    }
  }

  async getTransactions(userId: string): Promise<TokenTransaction[]> {
    const { data, error } = await supabase
      .from('token_transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      throw new Error('Failed to get transactions');
    }

    return data || [];
  }
}

export const tokenService = new TokenService();