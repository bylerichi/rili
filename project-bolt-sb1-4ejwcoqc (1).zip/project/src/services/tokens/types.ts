export interface TokenBalance {
  balance: number;
  updatedAt: string;
}

export interface TokenTransaction {
  id: string;
  amount: number;
  type: 'add' | 'spend';
  description: string;
  createdAt: string;
}

export interface TokenError {
  code: 'INSUFFICIENT_BALANCE' | 'DATABASE_ERROR' | 'INVALID_AMOUNT';
  message: string;
}