import axios from 'axios';
import { RECRAFT_API } from './constants';
import type { CreateStyleResponse, StyleUploadOptions } from './types';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;

export async function createCustomStyle({ style, files }: StyleUploadOptions): Promise<string> {
  if (files.length === 0 || files.length > 5) {
    throw new Error('You must provide between 1 and 5 images');
  }

  const formData = new FormData();
  formData.append('style', style);
  
  // Add files with exact key as per API docs
  files.forEach(file => {
    formData.append('file', file);
  });

  try {
    const response = await axios.post<CreateStyleResponse>(
      `${RECRAFT_API.BASE_URL}/${RECRAFT_API.VERSION}${RECRAFT_API.ENDPOINTS.STYLES}`,
      formData,
      {
        headers: {
          'Authorization': `Bearer ${RECRAFT_API_KEY}`,
          'Content-Type': 'multipart/form-data'
        }
      }
    );

    if (!response.data?.id) {
      throw new Error('No style ID in response');
    }

    return response.data.id;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(`Style creation failed: ${error.response?.data?.message || error.message}`);
    }
    throw error;
  }
}