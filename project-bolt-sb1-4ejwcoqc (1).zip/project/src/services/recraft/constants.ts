export const RECRAFT_API = {
  BASE_URL: 'https://external.api.recraft.ai',
  VERSION: 'v1',
  ENDPOINTS: {
    GENERATE: '/images/generations',
    STYLES: '/styles'
  }
} as const;

export const DEFAULT_CONFIG = {
  resolution: '1024x1024',
  style: 'realistic_image',
  num_images: 1
} as const;

export const MAX_STYLE_IMAGES = 5;
export const MAX_CUSTOM_STYLES = 3;

export type RecraftStyle = 
  | 'realistic_image'
  | 'digital_illustration'
  | 'anime'
  | 'painting'
  | 'sketch'
  | 'comic_book'
  | 'pixel_art'
  | 'abstract';

export const STYLE_NAMES: Record<RecraftStyle, string> = {
  'realistic_image': 'Realistic',
  'digital_illustration': 'Digital Illustration',
  'anime': 'Anime',
  'painting': 'Painting',
  'sketch': 'Sketch',
  'comic_book': 'Comic Book',
  'pixel_art': 'Pixel Art',
  'abstract': 'Abstract'
} as const;