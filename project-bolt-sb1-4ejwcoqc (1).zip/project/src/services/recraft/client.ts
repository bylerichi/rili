import axios from 'axios';
import { RECRAFT_API, DEFAULT_CONFIG } from './constants';
import type { GenerateImageParams, RecraftResponse } from './types';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;

export async function generateImage(
  prompt: string,
  options: Partial<Omit<GenerateImageParams, 'prompt'>> = {}
): Promise<string> {
  const url = `${RECRAFT_API.BASE_URL}/${RECRAFT_API.VERSION}${RECRAFT_API.ENDPOINTS.GENERATE}`;
  
  try {
    // Prepare request body based on whether we're using a custom style or default style
    const requestBody = {
      prompt,
      resolution: options.resolution || DEFAULT_CONFIG.resolution,
      num_images: options.num_images || DEFAULT_CONFIG.num_images,
      ...(options.custom_style_id 
        ? { style_id: options.custom_style_id }  // Use style_id for custom styles
        : { style: options.style || DEFAULT_CONFIG.style }  // Use style for default styles
      )
    };

    console.log('Recraft API Request:', {
      url,
      body: requestBody
    });

    const response = await axios.post<RecraftResponse>(
      url,
      requestBody,
      {
        headers: {
          'Authorization': `Bearer ${RECRAFT_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('Recraft API Response:', response.data);

    const imageUrl = response.data?.data?.[0]?.url;
    if (!imageUrl) {
      throw new Error('No image URL in response');
    }

    return imageUrl;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('Recraft API Error:', {
        status: error.response?.status,
        data: error.response?.data,
        message: error.message
      });
      throw new Error(`Recraft API error: ${error.response?.data?.message || error.message}`);
    }
    throw error;
  }
}