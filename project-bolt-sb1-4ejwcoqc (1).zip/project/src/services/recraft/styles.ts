import axios from 'axios';
import { RECRAFT_API } from './constants';
import type { StylesResponse, CustomStyle } from './types';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;

export async function listCustomStyles(): Promise<CustomStyle[]> {
  try {
    const response = await axios.get<StylesResponse>(
      `${RECRAFT_API.BASE_URL}/${RECRAFT_API.VERSION}${RECRAFT_API.ENDPOINTS.STYLES}`,
      {
        headers: {
          'Authorization': `Bearer ${RECRAFT_API_KEY}`
        }
      }
    );

    return response.data.styles;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(`Failed to fetch styles: ${error.response?.data?.message || error.message}`);
    }
    throw error;
  }
}