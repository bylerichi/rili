const RECRAFT_API_KEY = process.env.VITE_RECRAFT_API_KEY;

async function testRecraftAPI() {
  try {
    console.log('Test de génération d\'image avec Recraft...');
    const prompt = "Red sports car on a white background";
    
    const response = await fetch('https://external.api.recraft.ai/v1/images/generations', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RECRAFT_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        resolution: '1024x1024',
        style: 'realistic_image',
        num_images: 1,
        guidance_scale: 7.5,
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log('Réponse complète:', JSON.stringify(data, null, 2));
    
    if (data?.data?.[0]?.url) {
      console.log('URL de l\'image:', data.data[0].url);
    } else {
      console.log('Pas d\'URL dans la réponse');
    }
  } catch (error) {
    console.error('Erreur lors du test:', error.message);
  }
}