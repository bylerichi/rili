import axios from 'axios';
import { RECRAFT_API } from './constants';
import type { ApiResponse } from './types';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;

export const api = {
  post: async <T>(endpoint: string, data: any, options: { isFormData?: boolean } = {}): Promise<ApiResponse<T>> => {
    try {
      const headers: Record<string, string> = {
        'Authorization': `Bearer ${RECRAFT_API_KEY}`
      };

      if (!options.isFormData) {
        headers['Content-Type'] = 'application/json';
      }

      const response = await axios.post<T>(
        `${RECRAFT_API.BASE_URL}/${RECRAFT_API.VERSION}${endpoint}`,
        data,
        { headers }
      );

      return { data: response.data, success: true };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        return {
          success: false,
          error: error.response?.data?.message || error.message
        };
      }
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }
};