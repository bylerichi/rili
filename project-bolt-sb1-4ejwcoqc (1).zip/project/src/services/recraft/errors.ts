export class RecraftError extends Error {
  constructor(
    message: string,
    public readonly status?: number,
    public readonly retryable: boolean = true
  ) {
    super(message);
    this.name = 'RecraftError';
  }
}

export class RecraftRateLimitError extends RecraftError {
  constructor(message: string) {
    super(message, 429, true);
    this.name = 'RecraftRateLimitError';
  }
}