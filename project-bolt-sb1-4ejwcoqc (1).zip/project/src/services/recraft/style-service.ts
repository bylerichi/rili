import { apiClient } from './api-client';
import { RECRAFT_API } from './constants';
import { validateStyleFiles } from './validators';
import type { CreateStyleResponse, StyleUploadOptions, CustomStyle } from './types';

class StyleService {
  private userId: string | null = null;
  private selectedStyleId: string | null = null;
  private userStyles: Map<string, CustomStyle> = new Map();

  setUserId(id: string) {
    this.userId = id;
  }

  setSelectedStyle(styleId: string) {
    this.selectedStyleId = styleId;
    if (this.userId) {
      localStorage.setItem(`style_${this.userId}`, styleId);
    }
  }

  getSelectedStyle(): string | null {
    if (!this.userId) return null;
    
    if (!this.selectedStyleId) {
      this.selectedStyleId = localStorage.getItem(`style_${this.userId}`);
    }
    return this.selectedStyleId;
  }

  async create({ style, files, name }: StyleUploadOptions): Promise<{ id: string; name: string }> {
    if (!this.userId) {
      throw new Error('User not authenticated');
    }

    validateStyleFiles(files);

    const formData = new FormData();
    formData.append('style', style);
    formData.append('name', name);
    
    files.forEach(file => {
      formData.append('reference_images', file);
    });

    const result = await apiClient.post<CreateStyleResponse>(
      RECRAFT_API.ENDPOINTS.STYLES,
      formData,
      { isFormData: true }
    );

    if (!result.success || !result.data) {
      throw new Error(result.error || 'Failed to create style');
    }

    // Store the style in the user's styles map
    this.userStyles.set(result.data.id, {
      id: result.data.id,
      name,
      thumbnailUrl: '', // Will be updated when testing the style
      userId: this.userId
    });

    // Save style in local storage
    this.setSelectedStyle(result.data.id);

    return {
      id: result.data.id,
      name
    };
  }

  async list(): Promise<CustomStyle[]> {
    if (!this.userId) {
      throw new Error('User not authenticated');
    }

    // Get styles from local storage
    const styles = Array.from(this.userStyles.values())
      .filter(style => style.userId === this.userId);

    return styles;
  }

  async delete(styleId: string): Promise<void> {
    if (!this.userId) {
      throw new Error('User not authenticated');
    }

    const result = await apiClient.delete(
      `${RECRAFT_API.ENDPOINTS.STYLES}/${styleId}`
    );

    if (!result.success) {
      throw new Error(result.error || 'Failed to delete style');
    }

    // Remove from user's styles map
    this.userStyles.delete(styleId);

    // Clear selected style if it was deleted
    if (this.selectedStyleId === styleId) {
      this.selectedStyleId = null;
      localStorage.removeItem(`style_${this.userId}`);
    }
  }

  // Update style thumbnail after testing
  updateStyleThumbnail(styleId: string, thumbnailUrl: string) {
    const style = this.userStyles.get(styleId);
    if (style) {
      style.thumbnailUrl = thumbnailUrl;
      this.userStyles.set(styleId, style);
    }
  }
}

export const styleService = new StyleService();