import { MAX_STYLE_IMAGES } from './constants';

export function validateStyleFiles(files: File[]): void {
  if (!files || files.length === 0) {
    throw new Error('At least one image is required');
  }

  if (files.length > MAX_STYLE_IMAGES) {
    throw new Error(`Maximum ${MAX_STYLE_IMAGES} images allowed`);
  }

  const invalidFiles = files.filter(file => file.type !== 'image/png');
  if (invalidFiles.length > 0) {
    throw new Error('All images must be in PNG format');
  }
}