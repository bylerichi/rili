import { RecraftStyle } from '../constants';

export function validateStyle(style: string): asserts style is RecraftStyle {
  const validStyles = [
    'realistic_image',
    'digital_illustration',
    'anime',
    'painting',
    'sketch',
    'comic_book',
    'pixel_art',
    'abstract'
  ] as const;

  if (!validStyles.includes(style as RecraftStyle)) {
    throw new Error(`Invalid style: ${style}. Must be one of: ${validStyles.join(', ')}`);
  }
}