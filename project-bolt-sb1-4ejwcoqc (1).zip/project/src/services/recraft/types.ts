export interface GenerateImageParams {
  prompt: string;
  style?: RecraftStyle;
  custom_style_id?: string;
  resolution?: string;
  num_images?: number;
}

export interface RecraftResponse {
  data: Array<{
    url: string;
  }>;
}

export interface StyleUploadOptions {
  style: RecraftStyle;
  files: File[];
  name: string;
}

export interface CreateStyleResponse {
  id: string;
}

export interface CustomStyle {
  id: string;
  name: string;
  thumbnailUrl: string;
  userId: string;
}

export interface ApiResponse<T> {
  data?: T;
  success: boolean;
  error?: string;
}