import axios from 'axios';
import { RECRAFT_API } from './constants';
import type { ApiResponse } from './types';

const RECRAFT_API_KEY = import.meta.env.VITE_RECRAFT_API_KEY;

class ApiClient {
  private baseUrl: string;
  private version: string;

  constructor() {
    this.baseUrl = RECRAFT_API.BASE_URL;
    this.version = RECRAFT_API.VERSION;
  }

  private getUrl(endpoint: string): string {
    return `${this.baseUrl}/${this.version}${endpoint}`;
  }

  private getHeaders(isFormData = false): Record<string, string> {
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${RECRAFT_API_KEY}`
    };

    if (!isFormData) {
      headers['Content-Type'] = 'application/json';
    }

    return headers;
  }

  async post<T>(endpoint: string, data: any, options: { isFormData?: boolean } = {}): Promise<ApiResponse<T>> {
    try {
      const response = await axios.post<T>(
        this.getUrl(endpoint),
        data,
        { 
          headers: this.getHeaders(options.isFormData),
          // Add this to properly handle FormData
          ...(options.isFormData ? { transformRequest: [] } : {})
        }
      );

      return { data: response.data, success: true };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        return {
          success: false,
          error: error.response?.data?.message || error.message
        };
      }
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }

  async get<T>(endpoint: string): Promise<ApiResponse<T>> {
    try {
      const response = await axios.get<T>(
        this.getUrl(endpoint),
        { headers: this.getHeaders() }
      );

      return { data: response.data, success: true };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        return {
          success: false,
          error: error.response?.data?.message || error.message
        };
      }
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }

  async delete(endpoint: string): Promise<ApiResponse<void>> {
    try {
      await axios.delete(
        this.getUrl(endpoint),
        { headers: this.getHeaders() }
      );

      return { success: true };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        return {
          success: false,
          error: error.response?.data?.message || error.message
        };
      }
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }
}

export const apiClient = new ApiClient();