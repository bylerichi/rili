import { generateImage } from './client';

async function testRecraftAPI() {
  try {
    console.log('Test de génération d\'image avec Recraft...');
    const prompt = "Red sports car on a white background";
    console.log('Prompt:', prompt);
    
    const imageUrl = await generateImage(prompt);
    
    console.log('Image générée avec succès!');
    console.log('URL de l\'image:', imageUrl);
  } catch (error) {
    console.error('Erreur lors du test:', error);
  }
}

console.log('Démarrage du test Recraft...');
testRecraftAPI();