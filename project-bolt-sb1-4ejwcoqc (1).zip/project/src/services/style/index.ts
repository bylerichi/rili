import { api } from '../api';
import { validateStyleInput } from './validators';
import type { StyleFormData, CreateStyleResult } from './types';

export const styleService = {
  createStyle: async (data: StyleFormData): Promise<CreateStyleResult> => {
    // Validate input
    validateStyleInput(data);

    // Prepare form data
    const formData = new FormData();
    formData.append('style', data.style);
    data.files.forEach(file => {
      formData.append('file', file);
    });

    // Create style
    const result = await api.post<{ id: string }>('/styles', formData, {
      isFormData: true
    });

    if (!result.success || !result.data) {
      throw new Error(result.error || 'Failed to create style');
    }

    // Generate preview image
    const previewUrl = await api.generatePreview(result.data.id);

    return {
      id: result.data.id,
      previewUrl
    };
  }
};