export const APP_CONFIG = {
  ENV: import.meta.env.MODE,
  IS_DEV: import.meta.env.DEV,
  IS_PROD: import.meta.env.PROD
} as const;

export const REQUIRED_ENV_VARS = {
  // Supabase
  SUPABASE_URL: 'VITE_SUPABASE_URL',
  SUPABASE_ANON_KEY: 'VITE_SUPABASE_ANON_KEY',
  
  // AI Services
  OPENAI_API_KEY: 'VITE_OPENAI_API_KEY',
  RECRAFT_API_KEY: 'VITE_RECRAFT_API_KEY',
  
  // Payment Services
  PAYPAL_CLIENT_ID: 'VITE_PAYPAL_CLIENT_ID'
} as const;