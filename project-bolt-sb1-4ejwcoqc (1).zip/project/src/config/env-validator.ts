import { REQUIRED_ENV_VARS } from './constants';

export class EnvError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'EnvError';
  }
}

export function validateEnvironment(): void {
  const requiredVars = {
    // Supabase
    SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL,
    SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY,
    
    // AI Services
    OPENAI_API_KEY: import.meta.env.VITE_OPENAI_API_KEY,
    RECRAFT_API_KEY: import.meta.env.VITE_RECRAFT_API_KEY,
    
    // Payment Services
    PAYPAL_CLIENT_ID: import.meta.env.VITE_PAYPAL_CLIENT_ID
  };

  const missing = Object.entries(requiredVars)
    .filter(([_, value]) => !value)
    .map(([name]) => name);

  if (missing.length > 0) {
    throw new EnvError(
      `Missing required environment variables: ${missing.join(', ')}`
    );
  }
}