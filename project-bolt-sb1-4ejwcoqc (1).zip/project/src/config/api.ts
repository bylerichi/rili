export const API_CONFIG = {
  recraft: {
    baseUrl: 'https://api.recraft.ai',
    version: 'v1',
    endpoints: {
      generate: '/generate' // Correct endpoint
    },
    defaults: {
      width: 1024,
      height: 1024,
      numImages: 1,
      guidanceScale: 7.5
    }
  }
} as const;