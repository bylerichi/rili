export const PAYMENT_CONFIG = {
  paypal: {
    clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
    sandbox: import.meta.env.VITE_PAYPAL_SANDBOX === 'true',
    currency: 'USD'
  }
} as const;