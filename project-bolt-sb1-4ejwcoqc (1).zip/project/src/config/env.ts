export interface EnvConfig {
  supabase: {
    url: string;
    anonKey: string;
  };
  paypal: {
    clientId: string;
    sandbox: boolean;
  };
}

export function validateEnv(): EnvConfig {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
  const paypalClientId = import.meta.env.VITE_PAYPAL_CLIENT_ID;

  if (!supabaseUrl) throw new Error('VITE_SUPABASE_URL is required');
  if (!supabaseAnonKey) throw new Error('VITE_SUPABASE_ANON_KEY is required');
  if (!paypalClientId) throw new Error('VITE_PAYPAL_CLIENT_ID is required');

  return {
    supabase: {
      url: supabaseUrl,
      anonKey: supabaseAnonKey
    },
    paypal: {
      clientId: paypalClientId,
      sandbox: import.meta.env.DEV // Use sandbox in development
    }
  };
}