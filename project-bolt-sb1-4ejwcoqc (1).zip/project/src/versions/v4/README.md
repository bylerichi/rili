# Recipe Generator V4

Enhanced version with batch recipe generation and custom styles.

## Features

- Batch recipe generation
- Custom style management
- Enhanced error handling
- Improved file organization
- Better TypeScript support

## Project Structure

```
src/
├── components/
│   ├── Dashboard/
│   │   ├── components/    # Shared dashboard components
│   │   ├── hooks/        # Custom hooks for recipe generation
│   │   └── utils/        # Utility functions
│   ├── CustomStyles/     # Style management components
│   └── StyleCreator/     # Style creation components
├── hooks/               # Global hooks
├── services/           # API services
│   ├── recipe/         # Recipe generation
│   └── recraft/        # Style management
└── utils/             # Utility functions
```

## Key Components

### BatchRecipeGenerator
- Multiple recipe generation
- Custom style selection
- Progress tracking
- Download functionality

### StyleManagement
- Custom style creation
- Style selection
- Style testing
- Style deletion

### Authentication
- User management
- Protected routes
- Session handling

## Technical Stack

- React 18
- TypeScript
- Custom Hooks
- Modular Architecture
- Enhanced Error Handling