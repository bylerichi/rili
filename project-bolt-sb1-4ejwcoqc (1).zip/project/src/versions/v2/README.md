# Recipe Generator V2

Enhanced version of the Recipe Generator with custom style creation and authentication.

## Features

- User authentication with Supabase
- Custom style creation with image upload
- File validation and preview
- Enhanced error handling
- Improved UI/UX

## Project Structure

```
src/
├── components/
│   ├── StyleCreator/     # Style creation components
│   │   ├── components/   # Shared components
│   │   └── hooks/        # Custom hooks
│   └── auth/             # Authentication components
├── hooks/                # Global hooks
├── services/
│   ├── recraft/         # Recraft API integration
│   └── auth/            # Authentication services
└── lib/                 # Core utilities

## Key Components

### StyleCreator
- Main component for creating custom styles
- Handles file upload and validation
- Integrates with Recraft API

### Authentication
- Supabase integration for user management
- Protected routes and session handling
- Login/Register functionality

### File Management
- File upload validation
- Preview functionality
- Progress tracking

## Technical Stack

- React 18
- TypeScript
- Supabase Auth
- Recraft API
- TailwindCSS
- Custom Hooks Pattern

## Best Practices

- Small, focused components
- Custom hooks for reusable logic
- Strong TypeScript typing
- Comprehensive error handling
- Progressive enhancement
```