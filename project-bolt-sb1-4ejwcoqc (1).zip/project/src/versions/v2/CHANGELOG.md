## Version 2.0.0

### Added
- Custom style creation with image upload
- Authentication system with Supabase
- File upload validation and preview
- Improved error handling
- Custom hooks for file management and style creation

### Changed
- Restructured components for better modularity
- Improved TypeScript types and validation
- Enhanced UI/UX with better feedback
- Optimized file handling

### Technical Details
- React + TypeScript
- Supabase Authentication
- Recraft API integration
- Custom hooks architecture
- File upload handling
- Improved error boundaries