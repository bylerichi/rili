# Changelog

## Version 1.0.0

Initial version with core features:

### Added
- Basic recipe generation using OpenAI
- Image generation using Recraft
- Batch recipe processing
- Recipe text and image downloads
- Clean UI with Tailwind CSS

### Technical Details
- React + TypeScript setup
- Vite for development and building
- Tailwind CSS for styling
- OpenAI GPT-4 integration
- Recraft API integration for image generation