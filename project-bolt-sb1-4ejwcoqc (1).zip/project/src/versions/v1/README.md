# Recipe Generator V1

This is the base version of the Recipe Generator application with core recipe generation functionality.

## Features

- Generate recipes with OpenAI
- Generate recipe images with Recraft
- Download recipe text and images
- Batch recipe generation

## Structure

```
src/
├── components/
│   ├── layout/        # Layout components
│   └── recipe/        # Recipe-related components
├── services/
│   ├── openai/        # OpenAI integration
│   ├── recraft/       # Recraft API integration
│   └── recipe/        # Recipe business logic
├── utils/             # Utility functions
└── types/             # TypeScript types
```

## Key Components

- `BatchRecipeGenerator`: Main component for generating multiple recipes
- `RecipeService`: Core service for recipe generation and parsing
- `RecraftClient`: Client for Recraft API integration