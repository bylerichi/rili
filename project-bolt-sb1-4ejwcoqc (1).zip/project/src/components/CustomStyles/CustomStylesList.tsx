import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { styleService } from '../../services/recraft/style-service';
import type { CustomStyle } from '../../services/recraft/types';

export function CustomStylesList() {
  const { user } = useAuth();
  const [styles, setStyles] = useState<CustomStyle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadStyles();
    }
  }, [user]);

  const loadStyles = async () => {
    try {
      styleService.setUserId(user!.id);
      const userStyles = await styleService.list();
      setStyles(userStyles);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to load styles');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectStyle = (styleId: string) => {
    styleService.setSelectedStyle(styleId);
  };

  const handleDeleteStyle = async (styleId: string) => {
    try {
      await styleService.delete(styleId);
      await loadStyles();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to delete style');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-md bg-red-50 p-4">
        <p className="text-sm text-red-700">{error}</p>
      </div>
    );
  }

  if (styles.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-lg">
        <p className="text-gray-600 mb-4">No custom styles yet.</p>
        <Link
          to="/styles/new"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
        >
          Create Your First Style
        </Link>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {styles.map((style) => (
        <div key={style.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
          {style.thumbnailUrl && (
            <img
              src={style.thumbnailUrl}
              alt={style.name}
              className="w-full h-48 object-cover"
            />
          )}
          <div className="p-4">
            <h3 className="text-lg font-semibold mb-4">{style.name}</h3>
            <div className="flex space-x-2">
              <button
                onClick={() => handleSelectStyle(style.id)}
                className="flex-1 bg-indigo-600 text-white px-3 py-2 rounded-md text-sm hover:bg-indigo-700"
              >
                Use Style
              </button>
              <button
                onClick={() => handleDeleteStyle(style.id)}
                className="flex-1 bg-red-600 text-white px-3 py-2 rounded-md text-sm hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}