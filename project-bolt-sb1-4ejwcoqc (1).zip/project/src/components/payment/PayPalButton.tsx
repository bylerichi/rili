import React, { useEffect, useRef } from 'react';
import { usePayPalSDK } from '../../hooks/usePayPalSDK';
import { usePayPalPayment } from '../../hooks/usePayPalPayment';
import type { TokenPackage } from '../../services/payment/types';

interface PayPalButtonProps {
  pkg: TokenPackage;
  onSuccess?: () => void;
  onError?: (error: string) => void;
}

export function PayPalButton({ pkg, onSuccess, onError }: PayPalButtonProps) {
  const { ready } = usePayPalSDK();
  const { handlePayment, handlePaymentSuccess } = usePayPalPayment();
  const buttonRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ready || !window.paypal || !buttonRef.current) return;

    const renderButton = async () => {
      try {
        // Clear existing buttons
        buttonRef.current!.innerHTML = '';

        await window.paypal.Buttons({
          createOrder: async () => {
            try {
              const orderId = await handlePayment(pkg);
              if (!orderId) throw new Error('Failed to create order');
              return orderId;
            } catch (error) {
              if (onError) onError('Failed to create order');
              throw error;
            }
          },
          onApprove: async (data: { orderID: string }) => {
            try {
              await handlePaymentSuccess(data.orderID, pkg.amount);
              if (onSuccess) onSuccess();
            } catch (error) {
              if (onError) onError('Payment failed');
            }
          },
          onError: (err: Error) => {
            if (onError) onError(err.message);
          }
        }).render(buttonRef.current);
      } catch (error) {
        if (onError) onError('Failed to initialize PayPal button');
      }
    };

    renderButton();
  }, [ready, pkg, handlePayment, handlePaymentSuccess, onSuccess, onError]);

  return <div ref={buttonRef} />;
}