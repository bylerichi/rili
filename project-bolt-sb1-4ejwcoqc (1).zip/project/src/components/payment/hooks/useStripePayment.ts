import { useState } from 'react';
import { stripeClient } from '../../../services/payment/stripe/client';
import type { TokenPackage } from '../../../services/payment/types';

export function useStripePayment() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [processingPackageId, setProcessingPackageId] = useState<string | null>(null);

  const handlePayment = async (pkg: TokenPackage) => {
    if (loading) return;

    setLoading(true);
    setError(null);
    setProcessingPackageId(pkg.id);

    try {
      await stripeClient.redirectToCheckout(pkg);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to initiate payment');
      setProcessingPackageId(null);
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    processingPackageId,
    handlePayment
  };
}