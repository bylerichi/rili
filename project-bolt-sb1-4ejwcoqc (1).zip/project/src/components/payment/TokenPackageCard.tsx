import React from 'react';
import type { TokenPackage } from '../../services/payment/types';

interface TokenPackageCardProps {
  pkg: TokenPackage;
  onPurchase: () => void;
  loading: boolean;
  processing: boolean;
}

export function TokenPackageCard({ pkg, onPurchase, loading, processing }: TokenPackageCardProps) {
  return (
    <div className="border rounded-lg p-4 text-center hover:border-indigo-500 transition-colors">
      <div className="text-2xl font-bold text-indigo-600 mb-2">
        {pkg.amount} tokens
      </div>
      <div className="text-gray-600 mb-4">${pkg.price} {pkg.currency}</div>
      <button
        onClick={onPurchase}
        disabled={loading || processing}
        className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50 relative"
      >
        {processing ? (
          <div className="flex items-center justify-center">
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
            <span>Processing...</span>
          </div>
        ) : (
          'Purchase with Stripe'
        )}
      </button>
    </div>
  );
}