import React, { useState } from 'react';
import { TOKEN_PACKAGES } from '../../services/payment/constants';
import { TokenPackageCard } from './TokenPackage';
import { usePayPalSDK } from '../../hooks/usePayPalSDK';

export function TokenPurchaseSection() {
  const { loading: sdkLoading, error: sdkError } = usePayPalSDK();
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSuccess = () => {
    setError(null);
    setSuccess('Payment successful! Your tokens have been added.');
    setTimeout(() => setSuccess(null), 5000);
  };

  const handleError = (error: string) => {
    setSuccess(null);
    setError(error);
  };

  if (sdkLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="h-8 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Purchase Tokens</h2>
      
      {sdkError && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">Failed to load PayPal: {sdkError}</p>
        </div>
      )}

      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {success && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-md">
          <p className="text-sm text-green-600">{success}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {TOKEN_PACKAGES.map(pkg => (
          <TokenPackageCard
            key={pkg.id}
            pkg={pkg}
            onSuccess={handleSuccess}
            onError={handleError}
          />
        ))}
      </div>
    </div>
  );
}