import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { payoneerClient } from '../../services/payment/payoneer/client';
import { TOKEN_PACKAGES } from '../../services/payment/constants';

export function PayoneerTokenPurchase() {
  const { user } = useAuth();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const handlePurchase = async (packageId: string) => {
    if (!user || loading) return;

    setLoading(true);
    setError(null);

    try {
      const pkg = TOKEN_PACKAGES.find(p => p.id === packageId);
      if (!pkg) throw new Error('Invalid package');

      const checkout = await payoneerClient.createCheckout(pkg.price);
      window.location.href = checkout.redirectUrl;
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to initiate payment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Purchase Tokens with Payoneer</h2>
      
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {TOKEN_PACKAGES.map(pkg => (
          <div 
            key={pkg.id}
            className="border rounded-lg p-4 text-center hover:border-indigo-500 transition-colors"
          >
            <div className="text-2xl font-bold text-indigo-600 mb-2">
              {pkg.amount} tokens
            </div>
            <div className="text-gray-600 mb-4">${pkg.price} {pkg.currency}</div>
            <button
              onClick={() => handlePurchase(pkg.id)}
              disabled={loading}
              className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
            >
              {loading ? 'Processing...' : 'Purchase with Payoneer'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}