import React from 'react';
import { PayPalButton } from './PayPalButton';
import type { TokenPackage } from '../../services/payment/types';

interface TokenPackageProps {
  pkg: TokenPackage;
  onSuccess?: () => void;
  onError?: (error: string) => void;
}

export function TokenPackageCard({ pkg, onSuccess, onError }: TokenPackageProps) {
  return (
    <div className="border rounded-lg p-4 text-center">
      <div className="text-2xl font-bold text-indigo-600 mb-2">
        {pkg.amount} tokens
      </div>
      <div className="text-gray-600 mb-4">
        ${pkg.price} {pkg.currency}
      </div>
      <PayPalButton
        pkg={pkg}
        onSuccess={onSuccess}
        onError={onError}
      />
    </div>
  );
}