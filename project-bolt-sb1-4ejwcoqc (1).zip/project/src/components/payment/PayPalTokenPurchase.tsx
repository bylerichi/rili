import React from 'react';
import { TOKEN_PACKAGES } from '../../services/payment/constants';
import { usePayment } from '../../hooks/usePayment';
import { usePayPalSDK } from '../../hooks/usePayPalSDK';
import { TokenPackageCard } from './TokenPackageCard';

export function PayPalTokenPurchase() {
  const { loading: sdkLoading, error: sdkError, ready } = usePayPalSDK();
  const { loading, error, success, handlePurchase, handlePaymentSuccess, clearStatus } = usePayment();

  const initializePayPalButtons = async (pkg: typeof TOKEN_PACKAGES[number]) => {
    if (!ready || !window.paypal) {
      console.error('PayPal SDK not ready');
      return;
    }

    try {
      const orderId = await handlePurchase(pkg);
      if (!orderId) return;

      window.paypal.Buttons({
        createOrder: () => Promise.resolve(orderId),
        onApprove: async (data: { orderID: string }) => {
          await handlePaymentSuccess(data.orderID, pkg.amount);
        },
        onError: (err: Error) => {
          clearStatus();
          console.error('PayPal button error:', err);
        }
      }).render(`#paypal-button-${pkg.id}`);
    } catch (error) {
      console.error('Failed to initialize PayPal buttons:', error);
    }
  };

  if (sdkLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="h-8 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (sdkError) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">Failed to load PayPal: {sdkError}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Purchase Tokens with PayPal</h2>
      
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {success && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-md">
          <p className="text-sm text-green-600">{success}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {TOKEN_PACKAGES.map(pkg => (
          <TokenPackageCard
            key={pkg.id}
            pkg={pkg}
            onPurchase={() => initializePayPalButtons(pkg)}
            disabled={loading || !ready}
          />
        ))}
      </div>
    </div>
  );
}