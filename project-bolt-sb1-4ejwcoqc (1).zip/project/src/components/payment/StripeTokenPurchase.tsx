import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useStripePayment } from './hooks/useStripePayment';
import { TOKEN_PACKAGES } from '../../services/payment/constants';
import { TokenPackageCard } from './TokenPackageCard';

export function StripeTokenPurchase() {
  const { user } = useAuth();
  const { loading, error, processingPackageId, handlePayment } = useStripePayment();

  const handlePurchase = async (packageId: string) => {
    if (!user || loading) return;

    const pkg = TOKEN_PACKAGES.find(p => p.id === packageId);
    if (!pkg) return;

    await handlePayment(pkg);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Purchase Tokens with Stripe</h2>
      
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {TOKEN_PACKAGES.map(pkg => (
          <TokenPackageCard
            key={pkg.id}
            pkg={pkg}
            onPurchase={() => handlePurchase(pkg.id)}
            loading={loading}
            processing={processingPackageId === pkg.id}
          />
        ))}
      </div>
    </div>
  );
}