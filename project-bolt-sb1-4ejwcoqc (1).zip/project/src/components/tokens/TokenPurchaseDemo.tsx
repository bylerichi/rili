import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { tokenService } from '../../services/tokens/token-service';

const TOKEN_PACKAGES = [
  { amount: 10, label: 'Starter Pack' },
  { amount: 25, label: 'Basic Pack' },
  { amount: 50, label: 'Pro Pack' },
  { amount: 100, label: 'Enterprise Pack' }
];

export function TokenPurchaseDemo() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handlePurchase = async (amount: number) => {
    if (!user || loading) return;

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      await tokenService.addTokens(user.id, amount, `Demo purchase of ${amount} tokens`);
      setSuccess(`Successfully added ${amount} tokens to your account!`);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to add tokens');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold">Get Tokens</h2>
        <p className="mt-2 text-sm text-gray-600">
          Click on a package to instantly add tokens to your account
        </p>
      </div>
      
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {success && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-md">
          <p className="text-sm text-green-600">{success}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {TOKEN_PACKAGES.map(pkg => (
          <button 
            key={pkg.amount}
            onClick={() => handlePurchase(pkg.amount)}
            disabled={loading}
            className="p-4 border rounded-lg text-center hover:border-indigo-500 transition-colors disabled:opacity-50"
          >
            <div className="text-2xl font-bold text-indigo-600 mb-2">
              {pkg.amount} tokens
            </div>
            <div className="text-gray-600">{pkg.label}</div>
          </button>
        ))}
      </div>
    </div>
  );
}