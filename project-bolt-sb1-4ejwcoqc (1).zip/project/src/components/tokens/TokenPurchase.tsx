import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { tokenService } from '../../services/tokens/token-service';

const TOKEN_PACKAGES = [
  { amount: 10, price: '$5' },
  { amount: 25, price: '$10' },
  { amount: 50, price: '$18' },
  { amount: 100, price: '$30' }
];

export function TokenPurchase() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePurchase = async (amount: number) => {
    if (!user || loading) return;

    setLoading(true);
    setError(null);

    try {
      await tokenService.purchaseTokens(user.id, amount);
      // Trigger balance refresh in parent component
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to purchase tokens');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Purchase Tokens</h2>
      
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {TOKEN_PACKAGES.map(pkg => (
          <div 
            key={pkg.amount}
            className="border rounded-lg p-4 text-center hover:border-indigo-500 transition-colors"
          >
            <div className="text-2xl font-bold text-indigo-600 mb-2">
              {pkg.amount} tokens
            </div>
            <div className="text-gray-600 mb-4">{pkg.price}</div>
            <button
              onClick={() => handlePurchase(pkg.amount)}
              disabled={loading}
              className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
            >
              {loading ? 'Processing...' : 'Purchase'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}