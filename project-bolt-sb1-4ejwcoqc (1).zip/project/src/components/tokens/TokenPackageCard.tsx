import React from 'react';
import type { TokenPackage } from '../../services/payment/types';

interface TokenPackageCardProps {
  pkg: TokenPackage;
  onPurchase: () => void;
  disabled?: boolean;
}

export function TokenPackageCard({ pkg, onPurchase, disabled }: TokenPackageCardProps) {
  return (
    <div className="border rounded-lg p-4 text-center hover:border-indigo-500 transition-colors">
      <div className="text-2xl font-bold text-indigo-600 mb-2">
        {pkg.amount} tokens
      </div>
      <div className="text-gray-600 mb-4">
        ${pkg.price} {pkg.currency}
      </div>
      <div id={`paypal-button-${pkg.id}`}>
        <button
          onClick={onPurchase}
          disabled={disabled}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {disabled ? 'Processing...' : 'Purchase with PayPal'}
        </button>
      </div>
    </div>
  );
}