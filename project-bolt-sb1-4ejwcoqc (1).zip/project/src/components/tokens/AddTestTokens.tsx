import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { tokenService } from '../../services/tokens/token-service';

export function AddTestTokens() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleAddTokens = async (amount: number) => {
    if (!user || loading) return;

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      await tokenService.addTokens(user.id, amount);
      setSuccess(`Successfully added ${amount} tokens to your account!`);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to add tokens');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold">Add Test Tokens</h2>
        <p className="mt-2 text-sm text-gray-600">
          Add tokens to test the recipe generation functionality.
        </p>
      </div>
      
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {success && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-md">
          <p className="text-sm text-green-600">{success}</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={() => handleAddTokens(10)}
          disabled={loading}
          className="p-4 border rounded-lg text-center hover:border-indigo-500 transition-colors"
        >
          <div className="text-2xl font-bold text-indigo-600 mb-2">10 tokens</div>
          <div className="text-gray-600">For single recipes</div>
        </button>

        <button
          onClick={() => handleAddTokens(50)}
          disabled={loading}
          className="p-4 border rounded-lg text-center hover:border-indigo-500 transition-colors"
        >
          <div className="text-2xl font-bold text-indigo-600 mb-2">50 tokens</div>
          <div className="text-gray-600">For batch testing</div>
        </button>

        <button
          onClick={() => handleAddTokens(100)}
          disabled={loading}
          className="p-4 border rounded-lg text-center hover:border-indigo-500 transition-colors"
        >
          <div className="text-2xl font-bold text-indigo-600 mb-2">100 tokens</div>
          <div className="text-gray-600">For full testing</div>
        </button>
      </div>
    </div>
  );
}