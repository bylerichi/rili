import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useTokenBalance } from '../../hooks/useTokenBalance';

export function TokenBalance() {
  const { user } = useAuth();
  const { balance, loading, error } = useTokenBalance(user?.id);

  if (!user) return null;

  if (loading) {
    return (
      <div className="animate-pulse bg-gray-100 h-8 w-24 rounded"></div>
    );
  }

  if (error) {
    return (
      <div className="text-sm text-red-600">Failed to load balance</div>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm text-gray-600">Balance:</span>
      <span className="font-medium">{balance} tokens</span>
    </div>
  );
}