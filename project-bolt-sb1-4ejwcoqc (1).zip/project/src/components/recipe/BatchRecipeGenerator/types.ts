export interface Recipe {
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
  hashtags: string;
}

export interface RecipeResult {
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  recipe?: Recipe;
  imageUrl?: string; // Changed from imageUrls array to single imageUrl
  error?: string;
}

export interface RecipeCardProps {
  result: RecipeResult;
}