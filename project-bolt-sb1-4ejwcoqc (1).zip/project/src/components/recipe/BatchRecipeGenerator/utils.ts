export function createDownloadLink(url: string, filename: string): void {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function sanitizeFilename(name: string): string {
  return name.toLowerCase().replace(/\s+/g, '-');
}

export function formatRecipeContent(recipe: {
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
  hashtags: string;
}): string {
  return `${recipe.title}\n\n` +
    `Description:\n${recipe.description}\n\n` +
    `Ingrédients:\n${recipe.ingredients}\n\n` +
    `Instructions:\n${recipe.instructions}\n\n` +
    `Tags: ${recipe.hashtags}`;
}