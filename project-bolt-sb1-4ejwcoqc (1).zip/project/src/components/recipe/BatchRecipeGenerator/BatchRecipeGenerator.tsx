import React, { useState } from 'react';
import { generateRecipe } from '../../../services/openai';
import { generateImage } from '../../../services/recraft/client';
import { parseRecipeText } from '../../../services/recipe/parser';
import type { RecipeResult } from './types';
import { RecipeCard } from './RecipeCard';

export function BatchRecipeGenerator() {
  const [recipeNames, setRecipeNames] = useState('');
  const [results, setResults] = useState<RecipeResult[]>([]);
  const [processing, setProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipeNames.trim() || processing) return;

    const names = recipeNames
      .split('\n')
      .map(name => name.trim())
      .filter(name => name)
      .slice(0, 25);

    if (names.length === 0) return;

    setProcessing(true);
    setResults(names.map(name => ({ name, status: 'pending' })));

    for (let i = 0; i < names.length; i++) {
      const name = names[i];
      
      setResults(prev => prev.map(result => 
        result.name === name 
          ? { ...result, status: 'processing' }
          : result
      ));

      try {
        // Generate recipe
        const recipeText = await generateRecipe(name);
        const parsed = parseRecipeText(recipeText);
        
        // Generate image
        const imageUrl = await generateImage(parsed.imagePrompt, {
          style: 'realistic_image'
        });
        
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'completed',
                recipe: {
                  title: parsed.title,
                  description: parsed.description,
                  ingredients: parsed.ingredients,
                  instructions: parsed.instructions,
                  hashtags: parsed.hashtags
                },
                imageUrl
              }
            : result
        ));
      } catch (error) {
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'error',
                error: error instanceof Error ? error.message : 'Unknown error'
              }
            : result
        ));
      }
    }

    setProcessing(false);
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-4">Générer plusieurs recettes</h2>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="mb-4">
          <label htmlFor="recipeNames" className="block text-sm font-medium text-gray-700">
            Noms des recettes (une par ligne, maximum 25)
          </label>
          <textarea
            id="recipeNames"
            value={recipeNames}
            onChange={(e) => setRecipeNames(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Gâteau au chocolat&#10;Tarte aux pommes&#10;Poulet rôti"
            rows={10}
            disabled={processing}
          />
        </div>

        <button
          type="submit"
          disabled={processing || !recipeNames.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {processing ? 'Génération en cours...' : 'Générer les recettes'}
        </button>
      </form>

      {results.length > 0 && (
        <div className="space-y-6">
          <h3 className="text-lg font-semibold">Résultats</h3>
          
          <div className="grid gap-6">
            {results.map((result) => (
              <RecipeCard key={result.name} result={result} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}