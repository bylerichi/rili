import React, { useState } from 'react';
import { generateRecipe } from '../../services/openai';
import { parseRecipeText } from '../../services/recipe/parser';

export function RecipeInput() {
  const [recipeName, setRecipeName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recipeText, setRecipeText] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipeName.trim() || loading) return;

    setLoading(true);
    setError(null);
    setRecipeText(null);

    try {
      const response = await generateRecipe(recipeName);
      const parts = parseRecipeText(response);
      
      // Créer le contenu du fichier texte avec toutes les sections
      const content = `${parts.title}\n\n` +
        `Description:\n${parts.description}\n\n` +
        `Ingrédients:\n${parts.ingredients}\n\n` +
        `Instructions:\n${parts.instructions}\n\n` +
        `Tags: ${parts.hashtags}`;
        
      setRecipeText(content);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!recipeText) return;
    
    const blob = new Blob([recipeText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${recipeName.toLowerCase().replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-4">Générer une recette</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="recipeName" className="block text-sm font-medium text-gray-700">
            Nom de la recette
          </label>
          <input
            type="text"
            id="recipeName"
            value={recipeName}
            onChange={(e) => setRecipeName(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Ex: Gâteau au chocolat"
            disabled={loading}
          />
        </div>

        <button
          type="submit"
          disabled={loading || !recipeName.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Génération en cours...' : 'Générer'}
        </button>
        
        {error && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-md">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        {recipeText && (
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-md">
              <pre className="whitespace-pre-wrap font-mono text-sm">{recipeText}</pre>
            </div>
            <button
              onClick={handleDownload}
              className="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
            >
              Télécharger la recette
            </button>
          </div>
        )}
      </form>
    </div>
  );
}