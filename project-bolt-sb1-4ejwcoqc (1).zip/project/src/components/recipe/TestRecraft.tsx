import React, { useState } from 'react';
import { generateImage } from '../../services/recraft/client';
import { generateRecipe } from '../../services/openai';
import { parseRecipeText } from '../../services/recipe/parser';

interface TestResult {
  urls?: string[];
  prompt?: string;
  error?: string;
}

export function TestRecraft() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TestResult | null>(null);

  const handleTest = async () => {
    setLoading(true);
    setResult(null);

    try {
      // Générer et parser la recette
      const recipeText = await generateRecipe("Chocolate cake");
      const parsed = parseRecipeText(recipeText);
      
      // Utiliser uniquement le prompt de vue du dessus
      const topViewPrompt = parsed.imagePrompt;

      // Générer les images avec le prompt de vue du dessus
      const { urls } = await generateImage(topViewPrompt);
      
      setResult({ urls, prompt: topViewPrompt });
    } catch (error) {
      setResult({ error: error instanceof Error ? error.message : 'Erreur inconnue' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-6 bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Test Recraft API</h2>
        <button
          onClick={handleTest}
          disabled={loading}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Génération...' : 'Tester Recraft'}
        </button>
      </div>

      {result && (
        <div className="mt-4">
          {result.error ? (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{result.error}</p>
            </div>
          ) : (
            <div>
              <div className="mb-4">
                <h3 className="font-semibold mb-2">Prompt Vue du Dessus:</h3>
                <p className="p-3 bg-gray-50 rounded">{result.prompt}</p>
              </div>
              <div>
                <p className="mb-2 text-green-600">Images générées avec succès !</p>
                <div className="grid grid-cols-2 gap-4">
                  {result.urls?.map((url, index) => (
                    <img 
                      key={index}
                      src={url} 
                      alt={`Test Recraft ${index + 1}`} 
                      className="max-w-full h-auto rounded-lg shadow-md"
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}