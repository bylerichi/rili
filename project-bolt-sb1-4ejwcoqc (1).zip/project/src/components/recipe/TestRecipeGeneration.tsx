import React, { useState } from 'react';
import { generateRecipe } from '../../services/openai';
import { generateImage } from '../../services/recraft/client';
import { parseRecipeText } from '../../services/recipe/parser';

interface TestResult {
  recipe?: {
    title: string;
    description: string;
    ingredients: string;
    instructions: string;
    hashtags: string;
  };
  imageUrl?: string;
  error?: string;
}

export function TestRecipeGeneration() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TestResult | null>(null);

  const handleTest = async () => {
    setLoading(true);
    setResult(null);

    try {
      // 1. Generate recipe text
      const recipeText = await generateRecipe("Chocolate lava cake");
      const parsed = parseRecipeText(recipeText);
      
      // 2. Generate image using the top view prompt with correct style
      const imageUrl = await generateImage(parsed.imagePrompt, {
        style: 'realistic_image'
      });
      
      setResult({
        recipe: {
          title: parsed.title,
          description: parsed.description,
          ingredients: parsed.ingredients,
          instructions: parsed.instructions,
          hashtags: parsed.hashtags
        },
        imageUrl
      });
    } catch (error) {
      setResult({
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-6 bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Test Recipe Generation</h2>
        <button
          onClick={handleTest}
          disabled={loading}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Recipe'}
        </button>
      </div>

      {result && (
        <div className="mt-4">
          {result.error ? (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{result.error}</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Recipe Content */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold">{result.recipe?.title}</h3>
                
                <div>
                  <h4 className="font-semibold mb-2">Description:</h4>
                  <p className="text-gray-700">{result.recipe?.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Ingredients:</h4>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe?.ingredients}</pre>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Instructions:</h4>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe?.instructions}</pre>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Tags:</h4>
                  <p className="text-gray-700">{result.recipe?.hashtags}</p>
                </div>
              </div>

              {/* Generated Image */}
              <div>
                <h4 className="font-semibold mb-2">Generated Image:</h4>
                <img 
                  src={result.imageUrl} 
                  alt="Generated recipe" 
                  className="max-w-full h-auto rounded-lg shadow-md"
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}