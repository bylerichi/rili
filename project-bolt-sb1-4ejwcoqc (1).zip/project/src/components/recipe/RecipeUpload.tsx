import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { parseCSV } from '../../utils/csv';
import { processRecipe } from '../../services/recipe';
import { validateRecipeData } from '../../utils/validation';
import type { RecipeRow } from '../../types/recipe';
import type { ProcessingStatus } from '../../types/progress';
import { ProgressBar } from '../ui/ProgressBar';
import { logError, formatError } from '../../utils/error';

export function RecipeUpload() {
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<ProcessingStatus | null>(null);

  const updateStatus = (newStatus: ProcessingStatus) => {
    setStatus(newStatus);
  };

  const onDrop = async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;

    setProcessing(true);
    setError(null);
    setStatus({ step: 'recipe', progress: 0, message: 'Analyzing file...' });

    try {
      const file = acceptedFiles[0];
      const recipes = await parseCSV(file);
      
      const pendingRecipes = recipes.filter((recipe: RecipeRow) => {
        try {
          validateRecipeData(recipe);
          return true;
        } catch (error) {
          logError('validateRecipeData', error);
          return false;
        }
      });

      if (pendingRecipes.length === 0) {
        throw new Error('No valid recipes to process');
      }

      for (const recipe of pendingRecipes) {
        try {
          updateStatus({ 
            step: 'recipe', 
            progress: 25, 
            message: `Generating recipe: ${recipe['Recipe Name']}` 
          });
          
          await processRecipe(recipe['Recipe Name']);
          
        } catch (error) {
          logError('processRecipe', error);
          setError(formatError(error));
          break;
        }
      }

      if (!error) {
        updateStatus({ step: 'images', progress: 100, message: 'Processing complete!' });
        setTimeout(() => window.location.reload(), 2000);
      }
    } catch (error) {
      logError('RecipeUpload.onDrop', error);
      setError(formatError(error));
    } finally {
      setTimeout(() => {
        setProcessing(false);
        setStatus(null);
      }, 2000);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv']
    },
    disabled: processing,
    multiple: false
  });

  return (
    <div className="p-6 bg-white rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-4">Import Recipes</h2>
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors ${
          processing ? 'bg-gray-100 cursor-not-allowed' : 'hover:border-indigo-500'
        } ${isDragActive ? 'border-indigo-500' : 'border-gray-300'}`}
      >
        <input {...getInputProps()} />
        {processing ? (
          <div className="space-y-4">
            <p className="text-gray-600 mb-2">Processing...</p>
            {status && <ProgressBar progress={status.progress} status={status.message} />}
          </div>
        ) : isDragActive ? (
          <p className="text-gray-600">Drop the file here...</p>
        ) : (
          <p className="text-gray-600">
            Drag and drop a CSV file here, or click to select
          </p>
        )}
      </div>
      {error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}
    </div>
  );
}