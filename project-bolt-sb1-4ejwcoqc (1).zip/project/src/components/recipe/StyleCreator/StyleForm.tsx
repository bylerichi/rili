import React, { useState } from 'react';
import type { RecraftStyle } from '../../../services/recraft/constants';
import { STYLE_NAMES } from '../../../services/recraft/constants';

interface StyleFormProps {
  onSubmit: (name: string, style: RecraftStyle) => void;
  loading: boolean;
}

export function StyleForm({ onSubmit, loading }: StyleFormProps) {
  const [styleName, setStyleName] = useState('');
  const [baseStyle, setBaseStyle] = useState<RecraftStyle>('realistic_image');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!styleName.trim() || loading) return;
    onSubmit(styleName, baseStyle);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Style Name</label>
        <input
          type="text"
          value={styleName}
          onChange={(e) => setStyleName(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          placeholder="My Custom Style"
          disabled={loading}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Base Style</label>
        <select
          value={baseStyle}
          onChange={(e) => setBaseStyle(e.target.value as RecraftStyle)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          disabled={loading}
        >
          {Object.entries(STYLE_NAMES).map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
      </div>

      <button
        type="submit"
        disabled={loading || !styleName.trim()}
        className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
      >
        {loading ? 'Creating Style...' : 'Create Style'}
      </button>
    </form>
  );
}