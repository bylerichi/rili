import React from 'react';

interface SuccessMessageProps {
  styleId: string;
  name: string;
  previewUrl: string;
}

export function SuccessMessage({ styleId, name, previewUrl }: SuccessMessageProps) {
  return (
    <div className="bg-white rounded-lg p-6 shadow-sm">
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
          <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-gray-900">Style Created Successfully!</h3>
        <p className="text-sm text-gray-500 mt-1">Your new style is ready to use</p>
      </div>

      <div className="rounded-lg overflow-hidden mb-6">
        <img 
          src={previewUrl} 
          alt="Style preview" 
          className="w-full h-64 object-cover"
        />
        <p className="text-xs text-gray-500 mt-2 text-center">
          Preview image generated with your new style
        </p>
      </div>

      <div className="text-center">
        <p className="text-sm text-gray-600 mb-2">Style ID:</p>
        <code className="px-2 py-1 bg-gray-100 rounded text-sm">{styleId}</code>
      </div>
    </div>
  );
}