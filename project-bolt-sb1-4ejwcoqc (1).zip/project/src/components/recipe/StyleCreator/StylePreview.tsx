import React, { useState } from 'react';
import { generateImage } from '../../../services/recraft/client';

interface StylePreviewProps {
  styleId: string;
  styleName: string;
}

export function StylePreview({ styleId, styleName }: StylePreviewProps) {
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generateTestImage = async () => {
    setLoading(true);
    setError(null);

    try {
      const url = await generateImage('A delicious cheesecake with fresh berries on top', {
        style: styleId
      });
      setImageUrl(url);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to generate test image');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Preview: {styleName}</h3>
        <button
          onClick={generateTestImage}
          disabled={loading}
          className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Test Image'}
        </button>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      {imageUrl && (
        <div className="mt-4">
          <p className="text-sm text-gray-600 mb-2">Generated Cheesecake Image:</p>
          <img 
            src={imageUrl} 
            alt="Test cheesecake" 
            className="w-full max-w-2xl mx-auto rounded-lg shadow-lg"
          />
        </div>
      )}
    </div>
  );
}