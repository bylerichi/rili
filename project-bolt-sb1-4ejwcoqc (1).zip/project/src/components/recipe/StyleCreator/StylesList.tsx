import React from 'react';
import { Link } from 'react-router-dom';
import { MAX_CUSTOM_STYLES } from '../../../services/recraft/constants';

interface Style {
  id: string;
  name: string;
  thumbnailUrl: string;
}

interface StylesListProps {
  styles: Style[];
  onSelectStyle: (styleId: string) => void;
}

export function StylesList({ styles, onSelectStyle }: StylesListProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {styles.map((style) => (
        <div key={style.id} className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="aspect-w-16 aspect-h-9">
            <img
              src={style.thumbnailUrl}
              alt={style.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-4">
            <h3 className="text-lg font-semibold mb-2">{style.name}</h3>
            <div className="flex space-x-2">
              <button
                onClick={() => onSelectStyle(style.id)}
                className="flex-1 bg-indigo-600 text-white px-3 py-2 rounded-md text-sm hover:bg-indigo-700"
              >
                Use Style
              </button>
              <button
                onClick={() => onSelectStyle(style.id)}
                className="flex-1 bg-red-600 text-white px-3 py-2 rounded-md text-sm hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      ))}
      
      {styles.length < MAX_CUSTOM_STYLES && (
        <Link
          to="/custom-styles/new"
          className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-gray-300 rounded-lg hover:border-indigo-500 hover:bg-indigo-50 transition-colors"
        >
          <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center mb-2">
            <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
          </div>
          <span className="text-sm font-medium text-gray-900">Create New Style ({styles.length}/{MAX_CUSTOM_STYLES})</span>
        </Link>
      )}
    </div>
  );
}