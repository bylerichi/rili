import { useState, useCallback } from 'react';
import { MAX_STYLE_IMAGES } from '../../../../services/recraft/constants';

interface UseStyleUploadReturn {
  files: File[];
  error: string | null;
  addFiles: (newFiles: File[]) => void;
  removeFile: (index: number) => void;
  clearFiles: () => void;
  remainingSlots: number;
}

export function useStyleUpload(): UseStyleUploadReturn {
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);

  const addFiles = useCallback((newFiles: File[]) => {
    if (files.length + newFiles.length > MAX_STYLE_IMAGES) {
      setError(`Maximum ${MAX_STYLE_IMAGES} images allowed`);
      return;
    }

    // Validate file types
    const validFiles = newFiles.filter(file => file.type === 'image/png');
    if (validFiles.length !== newFiles.length) {
      setError('Only PNG images are allowed');
      return;
    }

    setError(null);
    setFiles(prev => [...prev, ...validFiles]);
  }, [files]);

  const removeFile = useCallback((index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setError(null);
  }, []);

  const clearFiles = useCallback(() => {
    setFiles([]);
    setError(null);
  }, []);

  return {
    files,
    error,
    addFiles,
    removeFile,
    clearFiles,
    remainingSlots: MAX_STYLE_IMAGES - files.length
  };
}