import React, { useState } from 'react';
import { generateRecipe } from '../../services/openai';
import { parseRecipeText } from '../../services/recipe/parser';

export function TestPrompt() {
  const [result, setResult] = useState<{
    topViewPrompt?: string;
    closeUpPrompt?: string;
    error?: string;
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const handleTest = async () => {
    setLoading(true);
    setResult(null);
    
    try {
      const recipeText = await generateRecipe("Chocolate cake");
      const parsed = parseRecipeText(recipeText);
      
      setResult({
        topViewPrompt: parsed.topViewPrompt,
        closeUpPrompt: parsed.closeUpPrompt
      });
    } catch (error) {
      setResult({
        error: error instanceof Error ? error.message : 'Erreur inconnue'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-6 bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Test Parsing Prompts</h2>
        <button
          onClick={handleTest}
          disabled={loading}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Test en cours...' : 'Tester le parsing'}
        </button>
      </div>

      {result && (
        <div className="mt-4">
          {result.error ? (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{result.error}</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Prompt Vue du Dessus:</h3>
                <p className="p-3 bg-gray-50 rounded">{result.topViewPrompt}</p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Prompt Gros Plan:</h3>
                <p className="p-3 bg-gray-50 rounded">{result.closeUpPrompt}</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}