import React, { useEffect, useState } from 'react';
import { storage } from '../../lib/storage';
import { auth } from '../../lib/auth';

interface RecipeFiles {
  name: string;
  hasRecipe: boolean;
  hasTopView: boolean;
  hasCloseUp: boolean;
}

export function RecipeList() {
  const [recipes, setRecipes] = useState<RecipeFiles[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadRecipes();
  }, []);

  const loadRecipes = async () => {
    try {
      const user = await auth.getUser();
      if (!user) {
        setError('Utilisateur non connecté');
        return;
      }

      const recipeList = await storage.listRecipes(user.id);
      const recipeFiles: RecipeFiles[] = [];

      for (const recipe of recipeList) {
        const files = await storage.listFiles(user.id, recipe);
        recipeFiles.push({
          name: recipe,
          hasRecipe: files.includes('recipe.txt'),
          hasTopView: files.includes('top-view.jpg'),
          hasCloseUp: files.includes('close-up.jpg')
        });
      }

      setRecipes(recipeFiles);
    } catch (error) {
      setError('Erreur lors du chargement des recettes');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="p-6 text-gray-600">Chargement des recettes...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-600">{error}</div>;
  }

  if (recipes.length === 0) {
    return (
      <div className="p-6 text-gray-600">
        Aucune recette disponible. Importez un fichier pour commencer.
      </div>
    );
  }

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Vos Recettes</h2>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {recipes.map((recipe) => (
          <div key={recipe.name} className="bg-white rounded-lg shadow p-6">
            <h3 className="text-xl font-semibold mb-4">{recipe.name}</h3>
            <ul className="space-y-2">
              {recipe.hasRecipe && (
                <li className="flex items-center text-green-600">
                  <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/>
                  </svg>
                  Document texte
                </li>
              )}
              {recipe.hasTopView && (
                <li className="flex items-center text-green-600">
                  <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/>
                  </svg>
                  Image vue du dessus
                </li>
              )}
              {recipe.hasCloseUp && (
                <li className="flex items-center text-green-600">
                  <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/>
                  </svg>
                  Image gros plan
                </li>
              )}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}