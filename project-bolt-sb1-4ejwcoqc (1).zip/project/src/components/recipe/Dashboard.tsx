import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { BatchRecipeGenerator } from './BatchRecipeGenerator';

export function Dashboard() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h1 className="text-2xl font-bold mb-2">Welcome back!</h1>
        <p className="text-gray-600">
          {user?.email}
        </p>
      </div>

      <BatchRecipeGenerator />
    </div>
  );
}