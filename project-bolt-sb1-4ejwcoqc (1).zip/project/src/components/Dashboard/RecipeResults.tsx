import React from 'react';
import { downloadRecipeWithImage, downloadAllRecipes } from '../../utils/download';
import type { RecipeResult } from './types';

interface RecipeResultsProps {
  results: RecipeResult[];
}

export function RecipeResults({ results }: RecipeResultsProps) {
  const handleDownload = async (result: RecipeResult) => {
    try {
      await downloadRecipeWithImage(result);
    } catch (error) {
      console.error('Failed to download recipe:', error);
    }
  };

  const handleDownloadAll = async () => {
    try {
      await downloadAllRecipes(results);
    } catch (error) {
      console.error('Failed to download all recipes:', error);
    }
  };

  return (
    <div className="mt-8 space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Results</h3>
        {results.some(result => result.status === 'completed') && (
          <button
            onClick={handleDownloadAll}
            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
          >
            Download All Completed
          </button>
        )}
      </div>
      
      {results.map((result) => (
        <div 
          key={result.name}
          className={`p-4 rounded-lg border ${
            result.status === 'completed' ? 'border-green-200 bg-green-50' :
            result.status === 'error' ? 'border-red-200 bg-red-50' :
            result.status === 'processing' ? 'border-blue-200 bg-blue-50' :
            'border-gray-200 bg-gray-50'
          }`}
        >
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold">{result.name}</h4>
            <span className={`px-2 py-1 rounded text-sm ${
              result.status === 'completed' ? 'bg-green-100 text-green-800' :
              result.status === 'error' ? 'bg-red-100 text-red-800' :
              result.status === 'processing' ? 'bg-blue-100 text-blue-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {result.status === 'completed' ? 'Completed' :
               result.status === 'error' ? 'Error' :
               result.status === 'processing' ? 'Processing' :
               'Pending'}
            </span>
          </div>

          {result.error ? (
            <p className="text-red-600">{result.error}</p>
          ) : result.status === 'completed' && result.recipe && result.imageUrl ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <div>
                  <h5 className="font-semibold mb-1">Description:</h5>
                  <p className="text-gray-700">{result.recipe.description}</p>
                </div>
                <div>
                  <h5 className="font-semibold mb-1">Ingredients:</h5>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe.ingredients}</pre>
                </div>
                <div>
                  <h5 className="font-semibold mb-1">Instructions:</h5>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe.instructions}</pre>
                </div>
              </div>
              
              <div className="space-y-4">
                <img 
                  src={result.imageUrl} 
                  alt={result.name}
                  className="w-full h-48 object-cover rounded-lg"
                />
                
                <button
                  onClick={() => handleDownload(result)}
                  className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
                >
                  Download Recipe & Image
                </button>
              </div>
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}