import { useState } from 'react';
import { generateRecipe } from '../../../services/openai';
import { generateImage } from '../../../services/recraft/client';
import { parseRecipeText } from '../../../services/recipe/parser';
import type { RecipeResult } from '../types';

export function useRecipeGeneration() {
  const [results, setResults] = useState<RecipeResult[]>([]);
  const [processing, setProcessing] = useState(false);

  const generateRecipes = async (names: string[], selectedStyle: string) => {
    if (names.length === 0 || processing) return;

    setProcessing(true);
    setResults(names.map(name => ({ name, status: 'pending' })));

    for (let i = 0; i < names.length; i++) {
      const name = names[i];
      
      setResults(prev => prev.map(result => 
        result.name === name 
          ? { ...result, status: 'processing' }
          : result
      ));

      try {
        const recipeText = await generateRecipe(name);
        const parsed = parseRecipeText(recipeText);
        
        const imageUrl = await generateImage(parsed.imagePrompt, {
          ...(selectedStyle === 'realistic_image' 
            ? { style: 'realistic_image' }
            : { custom_style_id: selectedStyle }
          )
        });
        
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'completed',
                recipe: {
                  title: parsed.title,
                  description: parsed.description,
                  ingredients: parsed.ingredients,
                  instructions: parsed.instructions,
                  hashtags: parsed.hashtags
                },
                imageUrl
              }
            : result
        ));
      } catch (error) {
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'error',
                error: error instanceof Error ? error.message : 'Unknown error'
              }
            : result
        ));
      }
    }

    setProcessing(false);
  };

  return {
    results,
    processing,
    generateRecipes
  };
}