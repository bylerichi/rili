import React, { useState } from 'react';
import { generateRecipe } from '../../services/openai';
import { generateImage } from '../../services/recraft/client';
import { parseRecipeText } from '../../services/recipe/parser';
import { StyleSelector } from './StyleSelector';
import { RecipeResults } from './RecipeResults';
import type { RecipeResult } from './types';

export function BatchRecipeGenerator() {
  const [recipeNames, setRecipeNames] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic_image');
  const [results, setResults] = useState<RecipeResult[]>([]);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipeNames.trim() || processing) return;

    const names = recipeNames
      .split('\n')
      .map(name => name.trim())
      .filter(name => name)
      .slice(0, 25);

    if (names.length === 0) return;

    setProcessing(true);
    setError(null);
    setResults(names.map(name => ({ name, status: 'pending' })));

    for (let i = 0; i < names.length; i++) {
      const name = names[i];
      
      setResults(prev => prev.map(result => 
        result.name === name 
          ? { ...result, status: 'processing' }
          : result
      ));

      try {
        // Generate recipe
        const recipeText = await generateRecipe(name);
        const parsed = parseRecipeText(recipeText);
        
        // Generate image
        const imageUrl = await generateImage(parsed.imagePrompt, {
          ...(selectedStyle === 'realistic_image' 
            ? { style: 'realistic_image' }
            : { custom_style_id: selectedStyle }
          )
        });
        
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'completed',
                recipe: {
                  title: parsed.title,
                  description: parsed.description,
                  ingredients: parsed.ingredients,
                  instructions: parsed.instructions,
                  hashtags: parsed.hashtags
                },
                imageUrl
              }
            : result
        ));
      } catch (error) {
        setResults(prev => prev.map(result =>
          result.name === name
            ? {
                name,
                status: 'error',
                error: error instanceof Error ? error.message : 'Unknown error'
              }
            : result
        ));
      }
    }

    setProcessing(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Generate Recipes</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Recipe Names (one per line, maximum 25)
          </label>
          <textarea
            value={recipeNames}
            onChange={(e) => setRecipeNames(e.target.value)}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Chocolate cake&#10;Apple pie&#10;Chicken curry"
            rows={8}
            disabled={processing}
          />
        </div>

        <StyleSelector
          value={selectedStyle}
          onChange={setSelectedStyle}
          disabled={processing}
        />

        {error && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-md">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={processing || !recipeNames.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {processing ? 'Generating Recipes...' : 'Generate Recipes'}
        </button>
      </form>

      {results.length > 0 && (
        <RecipeResults results={results} />
      )}
    </div>
  );
}