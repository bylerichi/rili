import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { generateRecipe } from '../../services/openai';
import { generateImage } from '../../services/recraft/client';
import { parseRecipeText } from '../../services/recipe/parser';
import { StyleSelector } from './StyleSelector';

interface RecipeResult {
  recipe?: {
    title: string;
    description: string;
    ingredients: string;
    instructions: string;
    hashtags: string;
  };
  imageUrl?: string;
  error?: string;
}

export function RecipeGenerator() {
  const [recipeName, setRecipeName] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic_image');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RecipeResult | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipeName.trim() || loading) return;

    setLoading(true);
    setResult(null);

    try {
      const recipeText = await generateRecipe(recipeName);
      const parsed = parseRecipeText(recipeText);
      
      const imageUrl = await generateImage(parsed.imagePrompt, {
        ...(selectedStyle === 'realistic_image' 
          ? { style: 'realistic_image' }
          : { custom_style_id: selectedStyle }
        )
      });
      
      setResult({
        recipe: {
          title: parsed.title,
          description: parsed.description,
          ingredients: parsed.ingredients,
          instructions: parsed.instructions,
          hashtags: parsed.hashtags
        },
        imageUrl
      });
    } catch (error) {
      setResult({
        error: error instanceof Error ? error.message : 'An error occurred'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Generate Recipe</h2>
        <Link
          to="/styles/new"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
        >
          Create Custom Style
        </Link>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="recipeName" className="block text-sm font-medium text-gray-700">
            Recipe Name
          </label>
          <input
            type="text"
            id="recipeName"
            value={recipeName}
            onChange={(e) => setRecipeName(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="e.g., Chocolate Cake"
            disabled={loading}
          />
        </div>

        <StyleSelector
          value={selectedStyle}
          onChange={setSelectedStyle}
          disabled={loading}
        />

        <button
          type="submit"
          disabled={loading || !recipeName.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Recipe'}
        </button>
      </form>

      {result && (
        <div className="mt-6">
          {result.error ? (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{result.error}</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-xl font-bold">{result.recipe?.title}</h3>
                
                <div>
                  <h4 className="font-semibold mb-2">Description:</h4>
                  <p className="text-gray-700">{result.recipe?.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Ingredients:</h4>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe?.ingredients}</pre>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Instructions:</h4>
                  <pre className="whitespace-pre-wrap text-gray-700">{result.recipe?.instructions}</pre>
                </div>
              </div>

              {result.imageUrl && (
                <div>
                  <h4 className="font-semibold mb-2">Generated Image:</h4>
                  <img 
                    src={result.imageUrl} 
                    alt="Generated recipe" 
                    className="w-full h-auto rounded-lg shadow-md"
                  />
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}