import React from 'react';
import type { RecipeResult } from '../types';

interface RecipeCardProps {
  result: RecipeResult;
  onDownloadText: (result: RecipeResult) => void;
  onDownloadImage: (result: RecipeResult) => void;
}

export function RecipeCard({ result, onDownloadText, onDownloadImage }: RecipeCardProps) {
  return (
    <div 
      className={`p-4 rounded-lg border ${
        result.status === 'completed' ? 'border-green-200 bg-green-50' :
        result.status === 'error' ? 'border-red-200 bg-red-50' :
        result.status === 'processing' ? 'border-blue-200 bg-blue-50' :
        'border-gray-200 bg-gray-50'
      }`}
    >
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">{result.name}</h4>
        <span className={`px-2 py-1 rounded text-sm ${
          result.status === 'completed' ? 'bg-green-100 text-green-800' :
          result.status === 'error' ? 'bg-red-100 text-red-800' :
          result.status === 'processing' ? 'bg-blue-100 text-blue-800' :
          'bg-gray-100 text-gray-800'
        }`}>
          {result.status === 'completed' ? 'Completed' :
           result.status === 'error' ? 'Error' :
           result.status === 'processing' ? 'Processing' :
           'Pending'}
        </span>
      </div>

      {result.error ? (
        <p className="text-red-600">{result.error}</p>
      ) : result.status === 'completed' && result.recipe && result.imageUrl ? (
        <div className="space-y-4">
          <div className="flex gap-4">
            <button
              onClick={() => onDownloadText(result)}
              className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
            >
              Download Recipe
            </button>
            <button
              onClick={() => onDownloadImage(result)}
              className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              Download Image
            </button>
          </div>
          
          <img 
            src={result.imageUrl} 
            alt={result.name}
            className="w-full h-48 object-cover rounded-lg"
          />
        </div>
      ) : null}
    </div>
  );
}