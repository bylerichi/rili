export interface Recipe {
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
  hashtags: string;
}

export interface RecipeResult {
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  recipe?: Recipe;
  imageUrl?: string;
  error?: string;
}