import JSZip from 'jszip';
import type { RecipeResult } from '../types';

export function downloadText(result: RecipeResult): void {
  if (!result.recipe) return;
  
  const content = `${result.recipe.title}\n\n` +
    `Description:\n${result.recipe.description}\n\n` +
    `Ingredients:\n${result.recipe.ingredients}\n\n` +
    `Instructions:\n${result.recipe.instructions}\n\n` +
    `Tags: ${result.recipe.hashtags}`;
  
  const blob = new Blob([content], { type: 'text/plain' });
  downloadFile(blob, `${result.name.toLowerCase().replace(/\s+/g, '-')}.txt`);
}

export async function downloadImage(result: RecipeResult): Promise<void> {
  if (!result.imageUrl) return;
  
  try {
    const response = await fetch(result.imageUrl);
    const blob = await response.blob();
    downloadFile(blob, `${result.name.toLowerCase().replace(/\s+/g, '-')}.jpg`);
  } catch (error) {
    console.error('Error downloading image:', error);
  }
}

export async function downloadAllRecipes(results: RecipeResult[]): Promise<void> {
  const completedResults = results.filter(result => result.status === 'completed');
  if (completedResults.length === 0) return;

  const zip = new JSZip();

  for (const result of completedResults) {
    if (!result.recipe || !result.imageUrl) continue;

    // Add recipe text
    const content = `${result.recipe.title}\n\n` +
      `Description:\n${result.recipe.description}\n\n` +
      `Ingredients:\n${result.recipe.ingredients}\n\n` +
      `Instructions:\n${result.recipe.instructions}\n\n` +
      `Tags: ${result.recipe.hashtags}`;
    
    zip.file(`${result.name.toLowerCase().replace(/\s+/g, '-')}.txt`, content);

    // Add image
    try {
      const response = await fetch(result.imageUrl);
      const blob = await response.blob();
      zip.file(`${result.name.toLowerCase().replace(/\s+/g, '-')}.jpg`, blob);
    } catch (error) {
      console.error(`Failed to download image for ${result.name}:`, error);
    }
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  downloadFile(blob, 'recipes.zip');
}

function downloadFile(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}