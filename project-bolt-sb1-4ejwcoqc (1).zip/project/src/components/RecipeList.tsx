import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { auth } from '../lib/auth';

interface RecipeFiles {
  name: string;
  hasRecipe: boolean;
  hasTopView: boolean;
  hasCloseUp: boolean;
}

export function RecipeList() {
  const [recipes, setRecipes] = useState<RecipeFiles[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadRecipes();
  }, []);

  const loadRecipes = async () => {
    try {
      const user = await auth.getUser();
      if (!user) {
        setError('User not authenticated');
        return;
      }

      const { data: recipeList, error: listError } = await supabase.storage
        .from('recipes')
        .list(`${user.id}/`);

      if (listError) throw listError;

      const recipeFiles: RecipeFiles[] = [];

      for (const recipe of recipeList || []) {
        const { data: files, error: filesError } = await supabase.storage
          .from('recipes')
          .list(`${user.id}/${recipe.name}/`);

        if (filesError) throw filesError;

        recipeFiles.push({
          name: recipe.name,
          hasRecipe: files?.some(f => f.name === 'recipe.txt') || false,
          hasTopView: files?.some(f => f.name === 'top-view.jpg') || false,
          hasCloseUp: files?.some(f => f.name === 'close-up.jpg') || false
        });
      }

      setRecipes(recipeFiles);
    } catch (error) {
      setError('Failed to load recipes');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (recipeName: string, fileName: string) => {
    try {
      const user = await auth.getUser();
      if (!user) {
        setError('User not authenticated');
        return;
      }

      const { data } = await supabase.storage
        .from('recipes')
        .createSignedUrl(`${user.id}/${recipeName}/${fileName}`, 60);

      if (data?.signedUrl) {
        window.open(data.signedUrl, '_blank');
      }
    } catch (error) {
      setError('Failed to download file');
    }
  };

  if (loading) {
    return <div className="p-6 text-gray-600">Loading recipes...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-600">{error}</div>;
  }

  if (recipes.length === 0) {
    return (
      <div className="p-6 text-gray-600">
        No recipes available. Import a file to get started.
      </div>
    );
  }

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Your Recipes</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {recipes.map((recipe) => (
          <div key={recipe.name} className="border rounded-lg p-4">
            <h3 className="text-xl font-semibold mb-2">{recipe.name}</h3>
            <div className="space-y-2">
              {recipe.hasRecipe && (
                <button
                  onClick={() => handleDownload(recipe.name, 'recipe.txt')}
                  className="w-full bg-blue-500 text-white px-4 py-2 rounded"
                >
                  Download Recipe
                </button>
              )}
              {recipe.hasTopView && (
                <button
                  onClick={() => handleDownload(recipe.name, 'top-view.jpg')}
                  className="w-full bg-green-500 text-white px-4 py-2 rounded"
                >
                  Download Top View
                </button>
              )}
              {recipe.hasCloseUp && (
                <button
                  onClick={() => handleDownload(recipe.name, 'close-up.jpg')}
                  className="w-full bg-purple-500 text-white px-4 py-2 rounded"
                >
                  Download Close-up
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}