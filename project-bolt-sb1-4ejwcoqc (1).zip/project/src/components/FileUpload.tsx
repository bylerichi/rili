import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import { supabase } from '../lib/supabase';
import { auth } from '../lib/auth';
import { generateRecipe } from '../services/openai';
import { generateImage } from '../services/recraft';

interface RecipeRow {
  name: string;
  [key: string]: string;
}

export function FileUpload() {
  const processCSV = async (file: File) => {
    const text = await file.text();
    Papa.parse(text, {
      header: true,
      complete: async (results) => {
        const { data } = results;
        const user = await auth.getUser();
        if (!user) return;

        for (const row of data as RecipeRow[]) {
          try {
            // Generate recipe with ChatGPT
            const recipeText = await generateRecipe(row.name);
            const parts = recipeText.split('\n\n');
            
            const recipeName = parts[0];
            const topViewPrompt = parts[1];
            const closeUpPrompt = parts[2];
            const ingredients = parts[3];
            const instructions = parts[4];

            // Generate images
            const topViewImage = await generateImage(topViewPrompt);
            const closeUpImage = await generateImage(closeUpPrompt);

            // Save recipe text
            const recipeContent = `${ingredients}\n\n${instructions}`;
            const { error: textError } = await supabase.storage
              .from('recipes')
              .upload(`${user.id}/${recipeName}/recipe.txt`, recipeContent);

            if (textError) throw textError;

            // Save images
            const [topViewResponse, closeUpResponse] = await Promise.all([
              fetch(topViewImage),
              fetch(closeUpImage)
            ]);
            
            const [topViewBuffer, closeUpBuffer] = await Promise.all([
              topViewResponse.arrayBuffer(),
              closeUpResponse.arrayBuffer()
            ]);

            const [{ error: topViewError }, { error: closeUpError }] = await Promise.all([
              supabase.storage
                .from('recipes')
                .upload(`${user.id}/${recipeName}/top-view.jpg`, topViewBuffer),
              supabase.storage
                .from('recipes')
                .upload(`${user.id}/${recipeName}/close-up.jpg`, closeUpBuffer)
            ]);

            if (topViewError) throw topViewError;
            if (closeUpError) throw closeUpError;

          } catch (error) {
            console.error('Error processing row:', error);
          }
        }
      }
    });
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach(processCSV);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'text/csv': ['.csv']
    }
  });

  return (
    <div className="p-6">
      <div
        {...getRootProps()}
        className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center cursor-pointer hover:border-indigo-500"
      >
        <input {...getInputProps()} />
        {isDragActive ? (
          <p>Drop the file here...</p>
        ) : (
          <p>Drag and drop a CSV file here, or click to select</p>
        )}
      </div>
    </div>
  );
}