import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { styleService } from '../../services/recraft/style-service';
import { generateImage } from '../../services/recraft/client';
import { ImageUpload } from './ImageUpload';
import type { RecraftStyle } from '../../services/recraft/constants';

export function StyleCreator() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [styleName, setStyleName] = useState('');
  const [success, setSuccess] = useState<{
    styleId: string;
    name: string;
    previewUrl: string;
  } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || loading || files.length === 0 || !styleName.trim()) return;

    setLoading(true);
    setError(null);

    try {
      // Create the style
      styleService.setUserId(user.id);
      const { id: styleId } = await styleService.create({
        style: 'realistic_image' as RecraftStyle,
        files,
        name: styleName
      });

      // Generate a preview image
      const previewUrl = await generateImage(
        "A beautiful plate of food on a rustic wooden table with natural lighting", 
        { custom_style_id: styleId }
      );

      setSuccess({ styleId, name: styleName, previewUrl });
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to create style');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="bg-white rounded-lg p-6 shadow-sm">
        <div className="text-center">
          <div className="mb-4 text-green-600">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Style Created Successfully!</h3>
          <p className="text-sm text-gray-600 mb-4">Your new style is ready to use</p>
          
          <img 
            src={success.previewUrl} 
            alt="Style preview" 
            className="w-full max-w-2xl mx-auto rounded-lg shadow-lg mb-6"
          />

          <div className="flex justify-center space-x-4">
            <button
              onClick={() => navigate('/styles')}
              className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
            >
              View All Styles
            </button>
            <Link
              to="/"
              className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300"
            >
              Back to Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm">
      <h2 className="text-xl font-semibold mb-6">Create Custom Style</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="styleName" className="block text-sm font-medium text-gray-700 mb-1">
            Style Name
          </label>
          <input
            type="text"
            id="styleName"
            value={styleName}
            onChange={(e) => setStyleName(e.target.value)}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Enter a name for your style"
            disabled={loading}
            required
          />
        </div>

        <ImageUpload
          files={files}
          onFilesChange={setFiles}
          onRemoveFile={(index) => {
            setFiles(files.filter((_, i) => i !== index));
          }}
          disabled={loading}
        />

        {error && (
          <div className="rounded-md bg-red-50 p-4">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={loading || files.length === 0 || !styleName.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Creating Style...' : 'Create Style'}
        </button>
      </form>
    </div>
  );
}