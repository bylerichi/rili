import React, { useState } from 'react';
import { generateImage } from '../../services/recraft/client';
import { styleService } from '../../services/recraft/style-service';

interface StyleTesterProps {
  styleId: string;
  styleName: string;
}

export function StyleTester({ styleId, styleName }: StyleTesterProps) {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ imageUrl: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || loading) return;

    setLoading(true);
    setError(null);

    try {
      // Generate image using the custom style ID
      const imageUrl = await generateImage(prompt, {
        custom_style_id: styleId
      });
      
      // Update the style's thumbnail with the generated image
      styleService.updateStyleThumbnail(styleId, imageUrl);
      
      setResult({ imageUrl });
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to generate image');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-8 p-6 bg-gray-50 rounded-lg">
      <h3 className="text-lg font-medium text-gray-900 mb-4">
        Test Your Style: {styleName}
      </h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-gray-700">
            Image Prompt
          </label>
          <textarea
            id="prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Describe the image you want to generate..."
            rows={3}
            disabled={loading}
          />
        </div>

        {error && (
          <div className="rounded-md bg-red-50 p-4">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !prompt.trim()}
          className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Test Image'}
        </button>
      </form>

      {result && (
        <div className="mt-6">
          <h4 className="font-medium text-gray-900 mb-2">Generated Image:</h4>
          <img 
            src={result.imageUrl} 
            alt="Generated with custom style"
            className="w-full rounded-lg shadow-lg"
          />
        </div>
      )}
    </div>
  );
}