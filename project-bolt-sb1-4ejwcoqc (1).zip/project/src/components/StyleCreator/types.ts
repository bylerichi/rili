import type { RecraftStyle } from '../../services/recraft/constants';

export interface StyleFormData {
  style: RecraftStyle;
  files: File[];
  name: string;
}

export interface StyleCreatorProps {
  onStyleCreated?: (styleId: string) => void;
}