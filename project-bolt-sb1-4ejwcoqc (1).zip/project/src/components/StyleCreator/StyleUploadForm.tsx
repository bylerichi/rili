import React from 'react';
import { useStyleForm } from './hooks/useStyleForm';
import { ImageUpload } from './components/ImageUpload';
import { StyleSelect } from './components/StyleSelect';
import type { RecraftStyle } from '../../services/recraft/constants';

interface StyleUploadFormProps {
  onSubmit: (baseStyle: RecraftStyle, files: File[]) => Promise<void>;
  loading: boolean;
}

export function StyleUploadForm({ onSubmit, loading }: StyleUploadFormProps) {
  const { 
    style,
    files,
    error,
    handleStyleChange,
    handleFilesChange,
    handleRemoveFile,
    handleSubmit
  } = useStyleForm({ onSubmit });

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <StyleSelect 
        value={style} 
        onChange={handleStyleChange}
        disabled={loading}
      />

      <ImageUpload
        files={files}
        onFilesChange={handleFilesChange}
        onRemoveFile={handleRemoveFile}
        disabled={loading}
        error={error}
      />

      <button
        type="submit"
        disabled={loading || files.length === 0}
        className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
      >
        {loading ? 'Creating Style...' : 'Create Style'}
      </button>
    </form>
  );
}