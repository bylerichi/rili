import { useState } from 'react';
import { styleService } from '../../../services/recraft/style-service';
import type { RecraftStyle } from '../../../services/recraft/constants';

interface UseStyleCreationReturn {
  loading: boolean;
  error: string | null;
  success: { styleId: string; styleName: string } | null;
  createStyle: (style: RecraftStyle, files: File[], name: string) => Promise<void>;
}

export function useStyleCreation(userId: string): UseStyleCreationReturn {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<{ styleId: string; styleName: string } | null>(null);

  const createStyle = async (style: RecraftStyle, files: File[], name: string) => {
    setLoading(true);
    setError(null);

    try {
      styleService.setUserId(userId);
      const result = await styleService.create({ style, files, name });
      setSuccess({ styleId: result.id, styleName: result.name });
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to create style');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return { loading, error, success, createStyle };
}