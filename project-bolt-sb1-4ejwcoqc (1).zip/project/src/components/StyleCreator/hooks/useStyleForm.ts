import { useState, useCallback } from 'react';
import type { RecraftStyle } from '../../../services/recraft/constants';
import type { StyleFormData } from '../types';

export interface UseStyleFormProps {
  onSubmit: (data: StyleFormData) => Promise<void>;
}

export function useStyleForm({ onSubmit }: UseStyleFormProps) {
  const [style, setStyle] = useState<RecraftStyle>('digital_illustration');
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleStyleChange = useCallback((newStyle: RecraftStyle) => {
    setStyle(newStyle);
  }, []);

  const handleFilesChange = useCallback((newFiles: File[]) => {
    setFiles(prev => [...prev, ...newFiles]);
    setError(null);
  }, []);

  const handleRemoveFile = useCallback((index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (files.length === 0) {
      setError('Please select at least one image');
      return;
    }

    try {
      await onSubmit({ style, files, name: style });
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to create style');
    }
  }, [style, files, onSubmit]);

  return {
    style,
    files,
    error,
    handleStyleChange,
    handleFilesChange,
    handleRemoveFile,
    handleSubmit
  };
}