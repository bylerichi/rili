import { useState } from 'react';
import { MAX_STYLE_IMAGES } from '../../../services/recraft/constants';
import { processImages } from '../../../utils/image-processor';

interface UseFileUploadReturn {
  files: File[];
  error: string | null;
  addFiles: (newFiles: File[]) => Promise<void>;
  removeFile: (index: number) => void;
  clearFiles: () => void;
}

export function useFileUpload(): UseFileUploadReturn {
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);

  const addFiles = async (newFiles: File[]) => {
    try {
      if (files.length + newFiles.length > MAX_STYLE_IMAGES) {
        setError(`Maximum ${MAX_STYLE_IMAGES} images allowed`);
        return;
      }

      // Process and convert images
      const processedImages = await processImages(newFiles);
      
      setFiles(prev => [...prev, ...processedImages.map(img => img.file)]);
      setError(null);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to process images');
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setError(null);
  };

  const clearFiles = () => {
    setFiles([]);
    setError(null);
  };

  return { files, error, addFiles, removeFile, clearFiles };
}