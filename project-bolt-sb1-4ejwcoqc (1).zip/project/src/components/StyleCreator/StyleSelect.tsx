import React from 'react';
import type { RecraftStyle } from '../../services/recraft/constants';
import { STYLE_NAMES } from '../../services/recraft/constants';

interface StyleSelectProps {
  value: RecraftStyle;
  onChange: (value: RecraftStyle) => void;
  disabled?: boolean;
}

export function StyleSelect({ value, onChange, disabled }: StyleSelectProps) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">Base Style</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as RecraftStyle)}
        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        disabled={disabled}
      >
        {Object.entries(STYLE_NAMES).map(([value, label]) => (
          <option key={value} value={value}>{label}</option>
        ))}
      </select>
    </div>
  );
}