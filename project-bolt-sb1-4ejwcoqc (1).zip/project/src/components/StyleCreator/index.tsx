import React, { useState } from 'react';
import { styleService } from '../../services/recraft/style-service';
import { generateImage } from '../../services/recraft/client';
import type { RecraftStyle } from '../../services/recraft/constants';
import { StyleUploadForm } from './StyleUploadForm';

interface StyleCreatorProps {
  onStyleCreated: (styleId: string) => void;
}

export function StyleCreator({ onStyleCreated }: StyleCreatorProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (baseStyle: RecraftStyle, files: File[]) => {
    if (!files || files.length === 0) {
      setError('Please select at least one image');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Create the style
      const { id: styleId } = await styleService.create({
        style: baseStyle,
        files
      });

      // Call the callback with the style ID
      onStyleCreated(styleId);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to create style');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm">
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      <StyleUploadForm onSubmit={handleSubmit} loading={loading} />
    </div>
  );
}