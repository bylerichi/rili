import React from 'react';

interface FilePreviewProps {
  file: File;
  onRemove: () => void;
  disabled?: boolean;
}

export function FilePreview({ file, onRemove, disabled }: FilePreviewProps) {
  return (
    <div className="relative group">
      <img
        src={URL.createObjectURL(file)}
        alt="Style reference"
        className="w-full h-32 object-cover rounded-lg"
      />
      <button
        type="button"
        onClick={onRemove}
        disabled={disabled}
        className="absolute top-2 right-2 p-1.5 bg-red-600 text-white rounded-full 
          hover:bg-red-700 disabled:opacity-50 opacity-0 group-hover:opacity-100 
          transition-opacity duration-200"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
      <div className="absolute bottom-0 left-0 right-0 px-3 py-2 bg-black/50 text-white text-xs truncate rounded-b-lg">
        {file.name}
      </div>
    </div>
  );
}