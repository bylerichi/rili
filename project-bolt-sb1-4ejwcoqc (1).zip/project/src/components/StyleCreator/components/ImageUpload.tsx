import React from 'react';
import { useDropzone } from 'react-dropzone';
import { MAX_STYLE_IMAGES } from '../../../services/recraft/constants';
import { FilePreview } from './FilePreview';

interface ImageUploadProps {
  files: File[];
  onFilesChange: (files: File[]) => void;
  onRemoveFile: (index: number) => void;
  disabled?: boolean;
  error?: string | null;
}

export function ImageUpload({ files, onFilesChange, onRemoveFile, disabled, error }: ImageUploadProps) {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: onFilesChange,
    accept: {
      'image/png': ['.png']
    },
    maxFiles: MAX_STYLE_IMAGES,
    disabled
  });

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Reference Images (1-{MAX_STYLE_IMAGES} PNG images)
      </label>
      
      <div 
        {...getRootProps()} 
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors
          ${isDragActive ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300 hover:border-indigo-500'}
          ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} />
        <p className="text-gray-600">
          Drop PNG images here, or click to select files
        </p>
        <p className="text-sm text-gray-500 mt-1">
          {MAX_STYLE_IMAGES - files.length} slots remaining
        </p>
      </div>

      {error && (
        <p className="mt-2 text-sm text-red-600">{error}</p>
      )}

      {files.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-4">
          {files.map((file, index) => (
            <FilePreview
              key={index}
              file={file}
              onRemove={() => onRemoveFile(index)}
              disabled={disabled}
            />
          ))}
        </div>
      )}
    </div>
  );
}