import React from 'react';
import { useStyleForm } from './hooks/useStyleForm';
import { ImageUpload } from './ImageUpload';
import { StyleSelect } from './StyleSelect';
import type { StyleFormData } from './types';

interface StyleFormProps {
  onSubmit: (data: StyleFormData) => Promise<void>;
  loading: boolean;
}

export function StyleForm({ onSubmit, loading }: StyleFormProps) {
  const { 
    style,
    files,
    error,
    handleStyleChange,
    handleFilesChange,
    handleRemoveFile,
    handleSubmit
  } = useStyleForm(onSubmit);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <StyleSelect 
        value={style} 
        onChange={handleStyleChange}
        disabled={loading}
      />

      <ImageUpload
        files={files}
        onFilesChange={handleFilesChange}
        onRemoveFile={handleRemoveFile}
        disabled={loading}
        error={error}
      />

      <button
        type="submit"
        disabled={loading || files.length === 0}
        className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50"
      >
        {loading ? 'Creating Style...' : 'Create Style'}
      </button>
    </form>
  );
}