import React from 'react';

interface SuccessMessageProps {
  styleId: string;
  styleName: string;
}

export function SuccessMessage({ styleId, styleName }: SuccessMessageProps) {
  return (
    <div className="text-center">
      <div className="mb-4 text-green-600">
        <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
      </div>
      <h3 className="text-lg font-medium text-gray-900 mb-2">Style Created Successfully!</h3>
      <p className="text-sm text-gray-600 mb-2">Style Name: {styleName}</p>
      <p className="text-sm text-gray-600 mb-4">Style ID:</p>
      <code className="block bg-gray-100 rounded p-2 mb-4 font-mono text-sm">
        {styleId}
      </code>
    </div>
  );
}