import React from 'react';
import { useSupabaseInit } from '../../hooks/useSupabaseInit';

export function ConnectionStatus() {
  const { initialized, error } = useSupabaseInit();

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-md">
        <p className="text-red-600">Failed to connect to Supabase: {error}</p>
      </div>
    );
  }

  if (!initialized) {
    return (
      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
        <p className="text-yellow-600">Connecting to Supabase...</p>
      </div>
    );
  }

  return (
    <div className="p-4 bg-green-50 border border-green-200 rounded-md">
      <p className="text-green-600">Connected to Supabase successfully!</p>
    </div>
  );
}