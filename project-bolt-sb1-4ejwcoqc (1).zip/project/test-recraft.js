const RECRAFT_API_KEY = process.env.VITE_RECRAFT_API_KEY;

async function testRecraft() {
  try {
    console.log('Testing Recraft API...');
    const prompt = "Red car";
    
    const response = await fetch('https://api.recraft.ai/v1/generate', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RECRAFT_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        width: 1024,
        height: 1024,
        num_images: 1,
        guidance_scale: 7.5
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log('Generated image URL:', data.imageUrl);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

testRecraft();