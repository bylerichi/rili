import { mkdir, writeFile, readFile, readdir, stat } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// Configuration
const VERSION = '4.0.0';
const BACKUP_DIR = `backup/v4`;

async function createBackup() {
  try {
    // Create backup directory
    await mkdir('backup', { recursive: true });
    await mkdir(BACKUP_DIR, { recursive: true });

    // Create version info
    const versionInfo = {
      version: VERSION,
      date: new Date().toISOString(),
      description: 'Enhanced version with batch recipe generation and custom styles',
      features: [
        'Batch recipe generation',
        'Custom style management',
        'Enhanced error handling',
        'Improved file organization',
        'Better TypeScript support'
      ]
    };

    // Save version info
    await writeFile(
      join(BACKUP_DIR, 'version.json'),
      JSON.stringify(versionInfo, null, 2)
    );

    // Create directory structure
    const dirs = [
      'components',
      'components/Dashboard',
      'components/Dashboard/components',
      'components/Dashboard/hooks',
      'components/Dashboard/utils',
      'components/CustomStyles',
      'components/StyleCreator',
      'hooks',
      'services',
      'services/recipe',
      'services/recraft',
      'utils'
    ];

    for (const dir of dirs) {
      await mkdir(join(BACKUP_DIR, dir), { recursive: true });
    }

    // Copy source files
    async function copyFile(src, dest) {
      try {
        const content = await readFile(src, 'utf8');
        await writeFile(dest, content);
      } catch (error) {
        console.error(`Error copying ${src}:`, error.message);
      }
    }

    // Copy main files
    const filesToCopy = [
      'App.tsx',
      'index.tsx',
      'components/Dashboard/Dashboard.tsx',
      'components/Dashboard/BatchRecipeGenerator.tsx',
      'components/Dashboard/StyleSelector.tsx',
      'components/CustomStyles/CustomStylesList.tsx',
      'components/StyleCreator/StyleCreator.tsx',
      'services/recraft/client.ts',
      'services/recraft/style-service.ts',
      'services/recipe/parser.ts'
    ];

    for (const file of filesToCopy) {
      const src = join('src', file);
      const dest = join(BACKUP_DIR, file);
      
      // Create parent directory if it doesn't exist
      const dir = dirname(dest);
      await mkdir(dir, { recursive: true });
      
      await copyFile(src, dest);
    }

    console.log(`Backup v4 completed in ${BACKUP_DIR}`);
  } catch (error) {
    console.error('Backup failed:', error);
    process.exit(1);
  }
}

createBackup();