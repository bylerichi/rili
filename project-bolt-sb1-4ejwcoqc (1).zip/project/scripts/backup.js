const fs = require('fs');
const path = require('path');

// Configuration
const VERSION = '4.0.0';
const BACKUP_ROOT = 'backups';
const BACKUP_DIR = `v${VERSION.split('.')[0]}`;
const SOURCE_DIR = 'src';
const IGNORE_PATTERNS = [
  'node_modules',
  '.git',
  'dist',
  '.cache',
  'backups'
];

// Create backup directories
const backupPath = path.join(BACKUP_ROOT, BACKUP_DIR);
if (!fs.existsSync(BACKUP_ROOT)) {
  fs.mkdirSync(BACKUP_ROOT);
}
if (!fs.existsSync(backupPath)) {
  fs.mkdirSync(backupPath);
}

// Copy function with filtering
function copyDirectory(source, target) {
  if (IGNORE_PATTERNS.some(pattern => source.includes(pattern))) {
    return;
  }

  if (!fs.existsSync(target)) {
    fs.mkdirSync(target);
  }

  const files = fs.readdirSync(source);

  files.forEach(file => {
    const sourcePath = path.join(source, file);
    const targetPath = path.join(target, file);
    const stat = fs.statSync(sourcePath);

    if (stat.isDirectory()) {
      copyDirectory(sourcePath, targetPath);
    } else {
      fs.copyFileSync(sourcePath, targetPath);
    }
  });
}

// Create version info
const versionInfo = {
  version: VERSION,
  date: new Date().toISOString(),
  description: 'Enhanced version with batch recipe generation and custom styles'
};

fs.writeFileSync(
  path.join(backupPath, 'version.json'),
  JSON.stringify(versionInfo, null, 2)
);

// Copy project files
copyDirectory(SOURCE_DIR, path.join(backupPath, 'src'));

console.log(`Backup completed: ${backupPath}`);