const fs = require('fs');
const path = require('path');

// Configuration
const VERSION = '4.0.0';
const BACKUP_DIR = `backup/v4`;

// Create backup directory
if (!fs.existsSync('backup')) {
  fs.mkdirSync('backup');
}
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR);
}

// Create version info
const versionInfo = {
  version: VERSION,
  date: new Date().toISOString(),
  description: 'Enhanced version with batch recipe generation and custom styles',
  features: [
    'Batch recipe generation',
    'Custom style management',
    'Enhanced error handling',
    'Improved file organization',
    'Better TypeScript support'
  ]
};

// Save version info
fs.writeFileSync(
  path.join(BACKUP_DIR, 'version.json'),
  JSON.stringify(versionInfo, null, 2)
);

// Create directory structure
const dirs = [
  'components',
  'components/Dashboard',
  'components/Dashboard/components',
  'components/Dashboard/hooks',
  'components/Dashboard/utils',
  'components/CustomStyles',
  'components/StyleCreator',
  'hooks',
  'services',
  'services/recipe',
  'services/recraft',
  'utils'
];

dirs.forEach(dir => {
  const fullPath = path.join(BACKUP_DIR, dir);
  if (!fs.existsSync(fullPath)) {
    fs.mkdirSync(fullPath, { recursive: true });
  }
});

// Copy source files
function copyFile(src, dest) {
  try {
    const content = fs.readFileSync(src, 'utf8');
    fs.writeFileSync(dest, content);
  } catch (error) {
    console.error(`Error copying ${src}:`, error.message);
  }
}

// Copy main files
const filesToCopy = [
  'App.tsx',
  'index.tsx',
  'components/Dashboard/Dashboard.tsx',
  'components/Dashboard/BatchRecipeGenerator.tsx',
  'components/Dashboard/StyleSelector.tsx',
  'components/CustomStyles/CustomStylesList.tsx',
  'components/StyleCreator/StyleCreator.tsx',
  'services/recraft/client.ts',
  'services/recraft/style-service.ts',
  'services/recipe/parser.ts'
];

filesToCopy.forEach(file => {
  const src = path.join('src', file);
  const dest = path.join(BACKUP_DIR, file);
  
  // Create parent directory if it doesn't exist
  const dir = path.dirname(dest);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  copyFile(src, dest);
});

console.log(`Backup v4 completed in ${BACKUP_DIR}`);